package com.lucas.nova.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lucas.nova.data.ConversationMeta
import com.lucas.nova.ui.theme.GlassBorder
import com.lucas.nova.ui.theme.MenuItemSurface
import com.lucas.nova.ui.theme.NovaBlue
import com.lucas.nova.ui.theme.NovaPink
import com.lucas.nova.ui.theme.NovaPurple
import com.lucas.nova.ui.theme.TextPrimary
import com.lucas.nova.ui.theme.TextSecondary
import com.lucas.nova.ui.theme.TextTertiary

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun HistoryDrawer(
    visible: Boolean,
    assistantName: String,
    userName: String,
    conversations: List<ConversationMeta>,
    onDismiss: () -> Unit,
    onNewChat: () -> Unit,
    onOpenConversation: (String) -> Unit,
    onTogglePin: (String) -> Unit,
    onRename: (String, String) -> Unit,
    onDelete: (String) -> Unit,
    onOpenSettings: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var actionsFor by remember { mutableStateOf<ConversationMeta?>(null) }
    var renamingFor by remember { mutableStateOf<ConversationMeta?>(null) }

    val filtered = if (query.isBlank()) conversations
    else conversations.filter { it.title.contains(query, ignoreCase = true) }

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(200)),
        exit = fadeOut(tween(200))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0x40000000))
                .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onDismiss() }
        ) {
            AnimatedVisibility(
                visible = visible,
                enter = slideInHorizontally(
                    animationSpec = tween(340, easing = androidx.compose.animation.core.CubicBezierEasing(0.22f, 1f, 0.36f, 1f))
                ) { -it } + fadeIn(tween(220)),
                exit = slideOutHorizontally(
                    animationSpec = tween(260, easing = androidx.compose.animation.core.CubicBezierEasing(0.4f, 0f, 1f, 1f))
                ) { -it } + fadeOut(tween(180)),
                modifier = Modifier.fillMaxHeight()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(0.75f)
                        .shadow(10.dp)
                        .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { }
                        .background(Color(0xFFFCFDFF))
                        .border(1.dp, GlassBorder, RectangleShape)
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(top = 46.dp, start = 18.dp, end = 18.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            NovaOrb(size = 24.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(assistantName, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        DrawerAction(
                            icon = Icons.Filled.Add,
                            label = "Nouvelle discussion",
                            highlighted = true
                        ) { onNewChat(); onDismiss() }

                        OutlinedTextField(
                            value = query,
                            onValueChange = { query = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 2.dp)
                                .clip(RoundedCornerShape(16.dp)),
                            placeholder = {
                                Text(
                                    "Rechercher dans les discussions",
                                    color = TextTertiary,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.basicMarquee()
                                )
                            },
                            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = TextTertiary, modifier = Modifier.size(22.dp)) },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            keyboardOptions = KeyboardOptions.Default,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedBorderColor = Color.Transparent,
                                unfocusedBorderColor = Color.Transparent,
                                focusedContainerColor = MenuItemSurface,
                                unfocusedContainerColor = MenuItemSurface,
                                cursorColor = NovaBlue
                            )
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            "Récents",
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        if (filtered.isEmpty()) {
                            Text(
                                "Aucune conversation pour l'instant.",
                                color = TextTertiary,
                                fontSize = 13.sp,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        } else {
                            LazyColumn(modifier = Modifier.weight(1f)) {
                                items(filtered, key = { it.id }) { convo ->
                                    ConversationRow(
                                        convo = convo,
                                        onClick = { onOpenConversation(convo.id); onDismiss() },
                                        onLongPress = { actionsFor = convo }
                                    )
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            // Meme blanc que le reste du tiroir : avant, ce fond etait
                            // legerement plus gris/bleute que la colonne au-dessus,
                            // ce qui creait une cassure visible entre les deux zones.
                            .background(Color(0xFFFCFDFF))
                            .clickable { onOpenSettings(); onDismiss() }
                            .padding(horizontal = 18.dp, vertical = 16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(30.dp)
                                    .clip(CircleShape)
                                    .background(Brush.linearGradient(listOf(NovaPurple, NovaBlue))),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(userName.take(1).uppercase(), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(userName, color = TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Icon(Icons.Filled.Settings, contentDescription = "Réglages", tint = TextSecondary, modifier = Modifier.size(19.dp))
                    }
                }
            }
        }
    }

    actionsFor?.let { convo ->
        ConversationActionsSheet(
            convo = convo,
            onDismiss = { actionsFor = null },
            onTogglePin = { onTogglePin(convo.id); actionsFor = null },
            onRename = { actionsFor = null; renamingFor = convo },
            onDelete = { onDelete(convo.id); actionsFor = null }
        )
    }

    renamingFor?.let { convo ->
        RenameDialog(
            initialTitle = convo.title,
            onCancel = { renamingFor = null },
            onConfirm = { newTitle -> onRename(convo.id, newTitle); renamingFor = null }
        )
    }
}

@Composable
private fun DrawerAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, highlighted: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .padding(vertical = 10.dp, horizontal = if (highlighted) 4.dp else 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (highlighted) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(NovaPurple, NovaBlue))),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
            }
        } else {
            Icon(icon, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(24.dp).padding(start = 6.dp))
        }
        Spacer(modifier = Modifier.width(if (highlighted) 14.dp else 18.dp))
        Text(label, color = TextPrimary, fontSize = 16.sp, fontWeight = if (highlighted) FontWeight.Medium else FontWeight.Normal)
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun ConversationRow(convo: ConversationMeta, onClick: () -> Unit, onLongPress: () -> Unit) {
    // Plus d'icone "bulle de chat" a gauche : une liste de titres nus, sans
    // repetition d'icone identique sur chaque ligne, est plus minimaliste
    // et laisse le pin (quand present) comme seul repere visuel a droite.
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongPress)
            .padding(vertical = 11.dp, horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            convo.title,
            color = TextPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        if (convo.pinned) {
            Icon(
                Icons.Filled.PushPin,
                contentDescription = "Épinglée",
                tint = NovaPurple,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
private fun ConversationActionsSheet(
    convo: ConversationMeta,
    onDismiss: () -> Unit,
    onTogglePin: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x40000000))
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onDismiss() },
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(14.dp, RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { }
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .background(Color(0xFFFCFDFF))
                .padding(bottom = 24.dp, top = 8.dp)
        ) {
            Box(
                modifier = Modifier
                    .padding(top = 8.dp, bottom = 12.dp)
                    .align(Alignment.CenterHorizontally)
                    .width(38.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(50))
                    .background(TextTertiary)
            )
            Text(
                convo.title,
                color = TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 22.dp, vertical = 6.dp)
            )
            ActionRow(
                icon = if (convo.pinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                label = if (convo.pinned) "Désépingler" else "Épingler",
                onClick = onTogglePin
            )
            ActionRow(icon = Icons.Filled.DriveFileRenameOutline, label = "Renommer", onClick = onRename)
            ActionRow(icon = Icons.Filled.DeleteOutline, label = "Supprimer", onClick = onDelete, destructive = true)
        }
    }
}

@Composable
private fun ActionRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit, destructive: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 22.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = if (destructive) NovaPink else TextSecondary, modifier = Modifier.size(23.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Text(label, color = if (destructive) NovaPink else TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun RenameDialog(initialTitle: String, onCancel: () -> Unit, onConfirm: (String) -> Unit) {
    var value by remember { mutableStateOf(initialTitle) }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x66000000))
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onCancel() },
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp)
                .shadow(16.dp, RoundedCornerShape(24.dp))
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFFFFFFFF))
                .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { }
                .padding(22.dp)
        ) {
            Text("Renommer la discussion", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(modifier = Modifier.height(14.dp))
            OutlinedTextField(
                value = value,
                onValueChange = { value = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedBorderColor = NovaBlue,
                    unfocusedBorderColor = Color(0x1F0A0A2E),
                    cursorColor = NovaBlue
                )
            )
            Spacer(modifier = Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                Text(
                    "Annuler", color = TextSecondary, fontWeight = FontWeight.Medium,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable { onCancel() }.padding(horizontal = 14.dp, vertical = 10.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    "Valider", color = NovaPurple, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable { if (value.isNotBlank()) onConfirm(value) }.padding(horizontal = 14.dp, vertical = 10.dp)
                )
            }
        }
    }
}
