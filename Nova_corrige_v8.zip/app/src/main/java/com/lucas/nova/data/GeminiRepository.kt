package com.lucas.nova.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Client pour l'API Gemini (v1beta). Plusieurs cles API peuvent etre
 * fournies par [apiKeysProvider] : des qu'une requete echoue avec une
 * erreur 429 (limite gratuite atteinte), la cle suivante de la liste est
 * essayee automatiquement avant d'abandonner -- chaque cle/projet Google a
 * son propre quota gratuit separe, donc ca permet de continuer a utiliser
 * l'appli sans attendre des qu'on a plusieurs cles enregistrees. La meme
 * cle (celle qui finit par fonctionner) est utilisee pour tout : texte ET
 * generation d'images (Imagen fait partie de la meme famille d'API Google).
 *
 * Le modele texte utilise n'est pas fige : il vient du menu cache (tap sur
 * "Nova") et est fourni par [modelProvider].
 */
class GeminiRepository(
    private val apiKeysProvider: () -> List<String>,
    private val systemPromptProvider: () -> String,
    private val modelProvider: () -> String = { SettingsStore.DEFAULT_MODEL_ID }
) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    private val baseUrl = "https://generativelanguage.googleapis.com/v1beta/models"

    /** Normalise l'identifiant de modele fourni par [modelProvider] : le
     * prefixe "models/" est deja dans [baseUrl], donc si jamais un
     * identifiant contenant deja ce prefixe (ex. copie/colle depuis la
     * documentation Google) devait un jour passer par ici, on l'enleve
     * pour eviter un doublon "models/models/..." dans l'URL (=> erreur
     * "not found" de l'API). Les identifiants stockes dans SettingsStore
     * sont deja sans prefixe ("gemini-2.5-flash", pas
     * "models/gemini-2.5-flash"), donc ce garde-fou ne change rien en
     * temps normal. */
    private fun resolvedModel(): String = modelProvider().removePrefix("models/")

    sealed class Result {
        data class Success(val text: String, val imagePaths: List<String> = emptyList()) : Result()
        data class Failure(val message: String) : Result()
    }

    /** Evenement emis pendant un streaming texte : soit un morceau de texte
     * en plus (le texte COMPLET accumule jusqu'ici, pas juste le delta, pour
     * que l'appelant puisse juste remplacer le contenu affiche), soit la fin
     * (succes ou echec). */
    sealed class StreamEvent {
        data class Partial(val textSoFar: String) : StreamEvent()
        data class Done(val finalText: String) : StreamEvent()
        data class Error(val message: String) : StreamEvent()
    }

    private fun buildRequestBody(history: List<ChatMessage>, newMessage: String, imagePaths: List<String>): JSONObject {
        val contents = JSONArray()
        for (msg in history) {
            val turn = JSONObject()
            turn.put("role", if (msg.isUser) "user" else "model")
            val parts = JSONArray()
            if (msg.text.isNotBlank()) parts.put(JSONObject().put("text", msg.text))
            for (path in msg.imagePaths) {
                encodeImagePart(path)?.let { parts.put(it) }
            }
            if (parts.length() == 0) continue
            turn.put("parts", parts)
            contents.put(turn)
        }

        val userTurn = JSONObject()
        userTurn.put("role", "user")
        val userParts = JSONArray()
        if (newMessage.isNotBlank()) userParts.put(JSONObject().put("text", newMessage))
        for (path in imagePaths) {
            encodeImagePart(path)?.let { userParts.put(it) }
        }
        userTurn.put("parts", userParts)
        contents.put(userTurn)

        val body = JSONObject()
        body.put("contents", contents)

        val systemInstruction = JSONObject()
        val sysParts = JSONArray()
        sysParts.put(JSONObject().put("text", systemPromptProvider()))
        systemInstruction.put("parts", sysParts)
        body.put("system_instruction", systemInstruction)
        return body
    }

    /** Envoi "classique" (non streame) vers un modele Gemini texte. */
    suspend fun sendMessage(
        history: List<ChatMessage>,
        newMessage: String,
        imagePaths: List<String> = emptyList()
    ): Result =
        withContext(Dispatchers.IO) {
            val apiKeys = apiKeysProvider()
            if (apiKeys.isEmpty()) {
                return@withContext Result.Failure("Aucune cle API Gemini configuree. Va dans les reglages pour la coller.")
            }

            val body = buildRequestBody(history, newMessage, imagePaths)
            val model = resolvedModel()
            val url = "$baseUrl/$model:generateContent"
            val mediaType = "application/json; charset=utf-8".toMediaType()

            var lastFailure: Result.Failure = Result.Failure("Erreur inconnue.")
            for ((index, apiKey) in apiKeys.withIndex()) {
                try {
                    val requestBody = body.toString().toRequestBody(mediaType)
                    val request = Request.Builder()
                        .url(url)
                        .addHeader("x-goog-api-key", apiKey)
                        .addHeader("Content-Type", "application/json")
                        .post(requestBody)
                        .build()

                    client.newCall(request).execute().use { response ->
                        val responseBody = response.body?.string().orEmpty()

                        if (!response.isSuccessful) {
                            lastFailure = Result.Failure(friendlyErrorMessage(response.code, responseBody))
                            // 429 = limite gratuite atteinte sur cette cle :
                            // on essaie la suivante s'il y en a une, sinon on
                            // remonte le message d'erreur tel quel.
                            if (response.code == 429 && index < apiKeys.lastIndex) return@use
                            return@withContext lastFailure
                        }

                        val json = JSONObject(responseBody)
                        val candidates = json.optJSONArray("candidates")
                        if (candidates == null || candidates.length() == 0) {
                            return@withContext Result.Failure("Reponse vide de Gemini.")
                        }

                        val content = candidates.getJSONObject(0).optJSONObject("content")
                        val parts = content?.optJSONArray("parts")
                        val text = StringBuilder()
                        if (parts != null) {
                            for (i in 0 until parts.length()) {
                                val part = parts.getJSONObject(i)
                                if (part.has("text")) text.append(part.optString("text"))
                            }
                        }

                        return@withContext if (text.isEmpty()) {
                            Result.Failure("Reponse vide de Gemini.")
                        } else {
                            Result.Success(text.toString())
                        }
                    }
                } catch (e: Exception) {
                    lastFailure = Result.Failure("Erreur reseau : ${e.message}")
                }
            }
            lastFailure
        }

    /**
     * Generation d'images via "gemini-3-pro-image" (Nano Banana Pro).
     * Contrairement a l'ancien Imagen, ce n'est PLUS un modele "predict" a
     * part : c'est un modele Gemini a part entiere qui repond sur le MEME
     * endpoint ":generateContent" que les modeles texte (comme
     * gemini-3.6-flash), avec le meme format de requete "contents/parts".
     * La reponse contient l'image encodee en base64 dans un "part" de type
     * "inline_data" (le JSON renvoye par l'API peut aussi la nommer
     * "inlineData" selon la representation ; on gere les deux), qu'on
     * decode et sauvegarde comme fichier local pour l'afficher en bulle,
     * exactement comme une photo envoyee par l'utilisateur.
     */
    suspend fun generateImage(prompt: String, modelOverride: String? = null): Result = withContext(Dispatchers.IO) {
        val apiKeys = apiKeysProvider()
        if (apiKeys.isEmpty()) {
            return@withContext Result.Failure("Aucune cle API Gemini configuree. Va dans les reglages pour la coller.")
        }
        if (prompt.isBlank()) {
            return@withContext Result.Failure("Decris ce que tu veux comme image.")
        }

        val model = (modelOverride ?: resolvedModel()).removePrefix("models/")
        val url = "$baseUrl/$model:generateContent"
        val userTurn = JSONObject()
            .put("role", "user")
            .put("parts", JSONArray().put(JSONObject().put("text", prompt)))
        val body = JSONObject().put("contents", JSONArray().put(userTurn))
        val mediaType = "application/json; charset=utf-8".toMediaType()

        var lastFailure: Result.Failure = Result.Failure("Erreur inconnue.")
        for ((index, apiKey) in apiKeys.withIndex()) {
            try {
                val requestBody = body.toString().toRequestBody(mediaType)
                val request = Request.Builder()
                    .url(url)
                    .addHeader("x-goog-api-key", apiKey)
                    .addHeader("Content-Type", "application/json")
                    .post(requestBody)
                    .build()

                client.newCall(request).execute().use { response ->
                    val responseBody = response.body?.string().orEmpty()

                    if (!response.isSuccessful) {
                        lastFailure = Result.Failure(friendlyErrorMessage(response.code, responseBody))
                        if (response.code == 429 && index < apiKeys.lastIndex) return@use
                        return@withContext lastFailure
                    }

                    val json = JSONObject(responseBody)
                    val candidates = json.optJSONArray("candidates")
                    if (candidates == null || candidates.length() == 0) {
                        return@withContext Result.Failure("Nova n'a renvoye aucune image. Reessaie avec une autre description.")
                    }

                    val content = candidates.getJSONObject(0).optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    val generatedImagePaths = mutableListOf<String>()
                    if (parts != null) {
                        for (i in 0 until parts.length()) {
                            val part = parts.getJSONObject(i)
                            val inline = part.optJSONObject("inline_data") ?: part.optJSONObject("inlineData")
                            val base64 = inline?.optString("data").orEmpty()
                            if (base64.isNotBlank()) {
                                decodeAndSaveImage(base64)?.let { generatedImagePaths.add(it) }
                            }
                        }
                    }

                    return@withContext if (generatedImagePaths.isEmpty()) {
                        Result.Failure("Nova n'a renvoye aucune image exploitable.")
                    } else {
                        Result.Success(text = "", imagePaths = generatedImagePaths)
                    }
                }
            } catch (e: Exception) {
                lastFailure = Result.Failure("Erreur reseau : ${e.message}")
            }
        }
        lastFailure
    }

    /**
     * Version streamee (endpoint streamGenerateContent?alt=sse) : les
     * reponses arrivent morceau par morceau au lieu d'attendre la reponse
     * complete, pour un ressenti beaucoup plus rapide (le premier mot
     * s'affiche en general en moins d'une seconde au lieu d'attendre toute
     * la generation). Reservee aux modeles texte Gemini ; la generation
     * d'images (Imagen) passe par [generateImage] sur un endpoint different.
     */
    fun sendMessageStream(
        history: List<ChatMessage>,
        newMessage: String,
        imagePaths: List<String> = emptyList()
    ): Flow<StreamEvent> = callbackFlow {
        val apiKeys = apiKeysProvider()
        if (apiKeys.isEmpty()) {
            trySend(StreamEvent.Error("Aucune cle API Gemini configuree. Va dans les reglages pour la coller."))
            close()
            return@callbackFlow
        }

        val model = resolvedModel()
        val body = buildRequestBody(history, newMessage, imagePaths)
        val url = "$baseUrl/$model:streamGenerateContent?alt=sse"
        val mediaType = "application/json; charset=utf-8".toMediaType()

        // Cle a l'index [keyIndex] ; en cas de 429 (limite gratuite atteinte
        // sur cette cle) et s'il reste une autre cle enregistree, retente
        // automatiquement avec la suivante avant d'abandonner pour de bon.
        var currentCall: Call? = null

        fun attempt(keyIndex: Int) {
            val requestBody = body.toString().toRequestBody(mediaType)
            val request = Request.Builder()
                .url(url)
                .addHeader("x-goog-api-key", apiKeys[keyIndex])
                .addHeader("Content-Type", "application/json")
                .post(requestBody)
                .build()

            val call = client.newCall(request)
            currentCall = call
            val accumulated = StringBuilder()

            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    trySend(StreamEvent.Error("Erreur reseau : ${e.message}"))
                    close()
                }

                override fun onResponse(call: Call, response: Response) {
                    response.use { resp ->
                        if (!resp.isSuccessful) {
                            val raw = resp.body?.string().orEmpty()
                            if (resp.code == 429 && keyIndex < apiKeys.lastIndex) {
                                attempt(keyIndex + 1)
                                return
                            }
                            trySend(StreamEvent.Error(friendlyErrorMessage(resp.code, raw)))
                            close()
                            return
                        }
                        val byteStream = resp.body?.byteStream()
                        if (byteStream == null) {
                            trySend(StreamEvent.Error("Reponse vide de Gemini."))
                            close()
                            return
                        }
                        try {
                            val reader = BufferedReader(byteStream.reader())
                            var line: String?
                            while (true) {
                                line = reader.readLine() ?: break
                                if (!line.startsWith("data:")) continue
                                val jsonChunk = line.removePrefix("data:").trim()
                                if (jsonChunk.isBlank()) continue
                                val chunkText = extractChunkText(jsonChunk)
                                if (chunkText.isNotEmpty()) {
                                    accumulated.append(chunkText)
                                    trySend(StreamEvent.Partial(accumulated.toString()))
                                }
                            }
                            if (accumulated.isEmpty()) {
                                trySend(StreamEvent.Error("Reponse vide de Gemini."))
                            } else {
                                trySend(StreamEvent.Done(accumulated.toString()))
                            }
                        } catch (e: Exception) {
                            if (accumulated.isNotEmpty()) {
                                // On a deja recu du texte : mieux vaut le garder
                                // que de tout jeter a cause d'une coupure en
                                // toute fin de flux.
                                trySend(StreamEvent.Done(accumulated.toString()))
                            } else {
                                trySend(StreamEvent.Error("Connexion interrompue pendant la reponse."))
                            }
                        } finally {
                            close()
                        }
                    }
                }
            })
        }

        attempt(0)

        awaitClose { currentCall?.cancel() }
    }.flowOn(Dispatchers.IO)

    private fun extractChunkText(jsonChunk: String): String {
        return try {
            val json = JSONObject(jsonChunk)
            val candidates = json.optJSONArray("candidates") ?: return ""
            if (candidates.length() == 0) return ""
            val content = candidates.getJSONObject(0).optJSONObject("content") ?: return ""
            val parts = content.optJSONArray("parts") ?: return ""
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                sb.append(parts.getJSONObject(i).optString("text"))
            }
            sb.toString()
        } catch (e: Exception) {
            ""
        }
    }

    /**
     * Lit une image locale et la transforme en "inline_data" base64 au
     * format attendu par l'API Gemini pour l'analyse d'images (vision).
     */
    private fun encodeImagePart(path: String): JSONObject? {
        return try {
            val bytes = java.io.File(path).readBytes()
            if (bytes.isEmpty()) return null
            val base64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
            JSONObject().put(
                "inline_data",
                JSONObject()
                    .put("mime_type", "image/jpeg")
                    .put("data", base64)
            )
        } catch (e: Exception) {
            null
        }
    }

    /** Decode une image generee (base64) renvoyee par Imagen et l'enregistre
     * dans le stockage prive de l'appli, comme une photo envoyee par
     * l'utilisateur, pour reutiliser exactement le meme affichage en bulle
     * (bitmap local, pas une URL distante). */
    private fun decodeAndSaveImage(base64: String): String? {
        return try {
            if (base64.isBlank()) return null
            val bytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT)
            val dir = java.io.File(imagesDir ?: return null).apply { mkdirs() }
            val dest = java.io.File(dir, "${java.util.UUID.randomUUID()}.jpg")
            dest.writeBytes(bytes)
            dest.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    /** Dossier de stockage des images generees par Nova, injecte depuis
     * l'exterieur (voir ChatViewModel) pour ne pas dependre du Context ici. */
    var imagesDir: String? = null

    /**
     * Traduit les erreurs brutes de l'API Gemini/Imagen (souvent un gros
     * pave de texte technique en anglais, illisible pour l'utilisateur) en
     * messages courts et clairs en francais.
     */
    private fun friendlyErrorMessage(code: Int, rawBody: String): String {
        val rawMessage = try {
            JSONObject(rawBody).optJSONObject("error")?.optString("message")
        } catch (e: Exception) {
            null
        }.orEmpty()

        return when {
            code == 429 || rawMessage.contains("quota", ignoreCase = true) -> {
                val retrySeconds = Regex("retry in ([0-9.]+)s", RegexOption.IGNORE_CASE)
                    .find(rawMessage)
                    ?.groupValues
                    ?.getOrNull(1)
                    ?.toDoubleOrNull()
                    ?.let { kotlin.math.ceil(it).toInt() }
                if (retrySeconds != null) {
                    "Limite de requetes gratuites Gemini atteinte. Reessaie dans ${retrySeconds}s."
                } else {
                    "Limite de requetes gratuites Gemini atteinte pour le moment. Reessaie dans une minute."
                }
            }
            code == 400 || code == 403 -> "Cle API Gemini invalide ou refusee. Verifie-la dans les reglages."
            code == 401 -> "Cle API Gemini manquante ou invalide. Verifie-la dans les reglages."
            code in 500..599 -> "Le service Gemini est momentanement indisponible. Reessaie dans un instant."
            rawMessage.isNotBlank() -> rawMessage
            else -> "Erreur $code lors de l'appel a Gemini."
        }
    }
}
