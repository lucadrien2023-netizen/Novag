package com.lucas.nova.util

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognitionService
import android.speech.SpeechRecognizer

/**
 * Cree un SpeechRecognizer en excluant explicitement le propre stub de Nova
 * (NovaRecognitionService).
 *
 * HISTORIQUE DU BUG (2 corrections contradictoires qui se sont annulees) :
 *
 * 1) Version precedente : on cherchait un ComponentName explicite (moteur
 *    Google force en dur / decouverte via queryIntentServices) pour eviter
 *    que la reconnaissance ne se resolve vers notre propre stub
 *    NovaRecognitionService une fois Nova definie comme assistant par
 *    defaut. Ca marchait, mais forcer N'IMPORTE QUEL ComponentName cassait
 *    la connexion sur HyperOS (Xiaomi/Redmi) avec ERROR_SERVER_DISCONNECTED
 *    (code 11).
 *
 * 2) "Correctif" suivant (celui qui causait le bug actuel) : on est revenu
 *    a l'appel universel createSpeechRecognizer(context) SANS ComponentName,
 *    pour laisser Android resoudre lui-meme le moteur. Sauf que
 *    NovaRecognitionService.kt existe et se declare comme un moteur
 *    android.speech.RecognitionService valide (uniquement pour satisfaire
 *    l'eligibilite "appli assistante" sur MIUI/HyperOS, voir ce fichier).
 *    Or des qu'une appli devient l'assistant systeme par defaut, HyperOS/
 *    MIUI redirige generalement le moteur vocal SYSTEME vers le
 *    RecognitionService que CETTE MEME appli declare (exactement comme le
 *    fait Google Assistant avec son propre moteur). Resultat : l'appel
 *    universel se liait a notre propre NovaRecognitionService, qui ne fait
 *    AUCUNE vraie reconnaissance (il renvoie ERROR_CLIENT immediatement,
 *    voir NovaRecognitionService.kt) -> le micro captait bien le son (les
 *    barres d'amplitude bougent, ou pire, la respiration decorative des
 *    barres masque meme un micro totalement mort) mais rien n'etait JAMAIS
 *    transcrit, dans l'appli comme dans la bulle assistant, puisque les
 *    deux passent par NovaSpeech.createRecognizer().
 *
 * CORRECTIF ACTUEL : on cherche un moteur reel PARMI ceux qui declarent
 * android.speech.RecognitionService, en excluant explicitement notre propre
 * paquet (context.packageName), et en preferant Google s'il est present.
 * On ne force le ComponentName QUE si un tel candidat existe ; sinon on
 * retombe sur l'appel universel (utile sur les appareils ou un seul moteur
 * existe vraiment). La deconnexion ERROR_SERVER_DISCONNECTED de HyperOS
 * reste geree separement par la logique de reessai automatique deja en
 * place dans ChatScreen.kt / BubbleService.kt (onError, erreurs transitoires) :
 * inutile de sacrifier la resolution du bon moteur pour ca.
 */
object NovaSpeech {

    /**
     * Diagnostic du DERNIER moteur resolu par createRecognizer(), mis a jour
     * a chaque appel. Sert a afficher, directement dans le message d'erreur
     * montre a l'utilisateur, quel moteur a reellement ete utilise -- pour
     * savoir IMMEDIATEMENT si le bug documente plus haut est revenu (Nova
     * qui se lie a son propre stub casse) sans avoir a brancher le telephone
     * et lire les logs a chaque fois.
     */
    var lastEngineInfo: String = "non resolu"
        private set

    fun createRecognizer(context: Context): SpeechRecognizer? {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            lastEngineInfo = "aucun moteur de reconnaissance disponible sur ce telephone"
            return null
        }
        return try {
            val realEngine = findRealEngine(context)
            if (realEngine != null) {
                lastEngineInfo = "${realEngine.packageName} (cible explicitement)"
                SpeechRecognizer.createSpeechRecognizer(context, realEngine)
            } else {
                lastEngineInfo = "resolution automatique Android (aucun autre moteur trouve que le notre)"
                SpeechRecognizer.createSpeechRecognizer(context)
            }
        } catch (e: Exception) {
            lastEngineInfo = "exception a la creation : ${e.message}"
            null
        }
    }

    /**
     * Cherche un moteur de reconnaissance vocale reel (pas notre propre
     * stub). Renvoie null si aucun candidat CONNU n'est trouve, auquel cas
     * l'appelant retombe sur la resolution automatique d'Android.
     *
     * IMPORTANT -- liste BLANCHE, pas liste noire : on a d'abord essaye
     * d'exclure seulement les mauvais candidats connus (com.google.android.as),
     * et de prendre "n'importe quel autre candidat restant" comme repli.
     * Sur un appareil de test, ce repli a pioche com.google.android.tts --
     * qui est le moteur de SYNTHESE vocale (texte -> voix), pas de
     * reconnaissance (voix -> texte) ! Il declare quand meme l'intent-filter
     * android.speech.RecognitionService sur cet appareil, sans etre un
     * moteur de dictee utilisable -> ERROR_NO_MATCH systematique. La lecon :
     * ne JAMAIS faire confiance a un candidat juste parce qu'il n'est pas
     * dans une liste d'exclusion. On ne retient desormais QUE des paquets
     * dont on sait avec certitude qu'ils font de la vraie reconnaissance
     * vocale, dans l'ordre de preference ci-dessous. Si aucun n'est
     * present, on ne devine pas : on retombe sur l'appel universel et on
     * laisse Android choisir lui-meme.
     */
    private val KNOWN_REAL_STT_ENGINES = listOf(
        "com.google.android.googlequicksearchbox", // App Google : moteur cloud, le plus precis. Priorite 1.
        "com.google.android.as"                     // Android System Intelligence : moteur embarque/hors-ligne, mois precis mais fonctionnel. Repli seulement.
    )

    private fun findRealEngine(context: Context): ComponentName? {
        return try {
            val pm = context.packageManager
            val services = pm.queryIntentServices(
                Intent(RecognitionService.SERVICE_INTERFACE),
                PackageManager.MATCH_ALL
            )
            // On exclut systematiquement notre propre paquet : c'est
            // exactement ca qui provoquait le bug initial (voir commentaire
            // plus haut). Peu importe ce que le systeme aurait choisi par
            // defaut, Nova elle-meme ne doit jamais servir de moteur de
            // transcription.
            val candidates = services.filter { it.serviceInfo.packageName != context.packageName }
            if (candidates.isEmpty()) return null

            for (pkg in KNOWN_REAL_STT_ENGINES) {
                val match = candidates.firstOrNull { it.serviceInfo.packageName == pkg }
                if (match != null) {
                    return ComponentName(match.serviceInfo.packageName, match.serviceInfo.name)
                }
            }
            // Aucun moteur CONNU trouve : on ne devine surtout pas parmi les
            // candidats restants (voir com.google.android.tts ci-dessus).
            // null ici -> createRecognizer() retombe sur l'appel universel.
            null
        } catch (e: Exception) {
            null
        }
    }
}
