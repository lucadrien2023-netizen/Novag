package com.lucas.nova.data

import android.content.Context

/**
 * Un modele proposable dans le menu cache (accessible en tapant sur "Nova"
 * en haut de l'ecran). Une SEULE cle API Gemini est utilisee pour tout :
 * texte ET images (Imagen fait partie de la meme famille d'API Google).
 */
data class NovaModel(
    val id: String,
    val label: String,
    val generatesImages: Boolean = false
)

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("nova_settings", Context.MODE_PRIVATE)

    companion object {
        const val DEFAULT_NAME = "Nova"
        const val DEFAULT_SYSTEM_PROMPT =
            "Tu es Nova, un assistant personnel francophone, chaleureux, direct et efficace. " +
                "Reponds de maniere concise et naturelle, comme dans une conversation orale."

        const val DEFAULT_MODEL_ID = "gemini-3.6-flash"

        /** Tous les modeles debloques des qu'une seule et meme cle API
         * Gemini est renseignee (texte ET generation d'images). Identifiants
         * officiels Google STRICTEMENT verifies (aout 2026) :
         *  - "gemini-3.6-flash" : Flash principal, recommande par defaut.
         *  - "gemini-3.5-flash-lite" : Flash leger, economique/haut volume.
         *  - "gemini-3.1-pro-preview" : Pro / raisonnement approfondi.
         *  - "gemini-3-pro-image" (Nano Banana Pro) : generation d'images,
         *    c'est desormais un modele Gemini a part entiere qui repond sur
         *    l'endpoint ":generateContent" (comme les modeles texte), PAS
         *    sur ":predict" comme l'ancien Imagen -- voir
         *    GeminiRepository.generateImage(), qui a ete adapte en
         *    consequence pour lire les images depuis "inline_data"/
         *    "inlineData" dans les "parts" de la reponse, au lieu de
         *    "predictions"/"bytesBase64Encoded". */
        val AVAILABLE_MODELS = listOf(
            NovaModel(id = "gemini-3.6-flash", label = "Gemini 3.6 Flash (rapide, recommande)"),
            NovaModel(id = "gemini-3.1-pro-preview", label = "Gemini 3.1 Pro (raisonnement)"),
            NovaModel(id = "gemini-3.5-flash-lite", label = "Gemini 3.5 Flash Lite (economique)"),
            NovaModel(
                id = "gemini-3-pro-image",
                label = "Nano Banana Pro (genere des images)",
                generatesImages = true
            )
        )
    }

    /**
     * Plusieurs cles API Gemini peuvent desormais etre enregistrees : quand
     * une cle atteint sa limite gratuite (429), GeminiRepository bascule
     * automatiquement sur la suivante de la liste (chaque cle/projet Google
     * a son propre quota gratuit separe). Stockees comme une seule chaine
     * separee par "||" pour rester simple avec SharedPreferences.
     *
     * Retro-compatibilite : si l'ancienne cle unique ("gemini_api_key")
     * existe encore et que la nouvelle liste est vide, elle est migree
     * automatiquement en premiere cle de la liste.
     */
    fun getApiKeys(): List<String> {
        val stored = prefs.getString("gemini_api_keys", null)
        if (!stored.isNullOrBlank()) {
            return stored.split("||").map { it.trim() }.filter { it.isNotBlank() }
        }
        // Migration depuis l'ancien format a cle unique.
        val legacy = prefs.getString("gemini_api_key", null)
        return if (!legacy.isNullOrBlank()) listOf(legacy.trim()) else emptyList()
    }

    fun setApiKeys(keys: List<String>) {
        val cleaned = keys.map { it.trim() }.filter { it.isNotBlank() }
        prefs.edit()
            .putString("gemini_api_keys", cleaned.joinToString("||"))
            .remove("gemini_api_key")
            .apply()
    }

    fun addApiKey(key: String) {
        val trimmed = key.trim()
        if (trimmed.isBlank()) return
        val current = getApiKeys()
        if (trimmed !in current) setApiKeys(current + trimmed)
    }

    fun removeApiKey(key: String) {
        setApiKeys(getApiKeys().filter { it != key })
    }

    /** La cle "active" = toujours la premiere de la liste. Conservee pour
     * ne pas casser le code existant qui appelait getApiKey()/setApiKey(). */
    fun getApiKey(): String? = getApiKeys().firstOrNull()
    fun setApiKey(key: String) {
        val current = getApiKeys().filter { it != key.trim() }
        setApiKeys(listOf(key.trim()) + current)
    }

    fun getSelectedModel(): String = prefs.getString("selected_model", DEFAULT_MODEL_ID) ?: DEFAULT_MODEL_ID
    fun setSelectedModel(modelId: String) {
        prefs.edit().putString("selected_model", modelId).apply()
    }

    fun getBubbleEnabled(): Boolean = prefs.getBoolean("bubble_enabled", false)
    fun setBubbleEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("bubble_enabled", enabled).apply()
    }

    fun getBubbleScale(): Float = prefs.getFloat("bubble_scale", 1f)
    fun setBubbleScale(scale: Float) {
        prefs.edit().putFloat("bubble_scale", scale).apply()
    }

    /** Nom technique (Voice.name) de la voix TTS choisie par Lucas, ou null
     * pour laisser le systeme choisir la voix francaise par defaut. */
    fun getVoiceName(): String? = prefs.getString("tts_voice_name", null)
    fun setVoiceName(name: String?) {
        prefs.edit().putString("tts_voice_name", name).apply()
    }

    fun getAssistantName(): String = prefs.getString("assistant_name", DEFAULT_NAME) ?: DEFAULT_NAME
    fun setAssistantName(name: String) {
        prefs.edit().putString("assistant_name", name).apply()
    }

    /** Prenom de l'utilisateur, demande a l'ecran de bienvenue. */
    fun getUserName(): String = prefs.getString("user_name", "") ?: ""
    fun setUserName(name: String) {
        prefs.edit().putString("user_name", name).apply()
    }

    /** Vrai une fois que l'ecran de bienvenue (nom + cle API) a ete termine
     * ou explicitement passe, pour ne plus jamais le remontrer ensuite. */
    fun isOnboardingComplete(): Boolean = prefs.getBoolean("onboarding_complete", false)
    fun setOnboardingComplete(complete: Boolean) {
        prefs.edit().putBoolean("onboarding_complete", complete).apply()
    }

    fun getSystemPrompt(): String = prefs.getString("system_prompt", DEFAULT_SYSTEM_PROMPT) ?: DEFAULT_SYSTEM_PROMPT
    fun setSystemPrompt(prompt: String) {
        prefs.edit().putString("system_prompt", prompt).apply()
    }

    /** Modeles reellement debloques a l'instant T : tous, des qu'une seule
     * cle API Gemini est renseignee (texte ET images utilisent la meme). */
    fun unlockedModels(): List<NovaModel> {
        val hasKey = !getApiKey().isNullOrBlank()
        return if (hasKey) AVAILABLE_MODELS else emptyList()
    }
}
