package com.lucas.nova.bubble

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.lucas.nova.MainActivity
import com.lucas.nova.data.ChatMessage
import com.lucas.nova.data.GeminiRepository
import com.lucas.nova.data.SettingsStore
import com.lucas.nova.ui.theme.NovaTheme
import com.lucas.nova.util.NovaSpeech
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Service qui affiche la bulle Nova par-dessus les autres applications
 * (necessite la permission "Afficher par-dessus les autres applications").
 * Gere le micro reel (SpeechRecognizer), l'appel a Gemini et la synthese
 * vocale de la reponse.
 */
class BubbleService : Service(), LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry
    override val viewModelStore: ViewModelStore = ViewModelStore()

    private lateinit var windowManager: WindowManager
    private var composeView: ComposeView? = null
    private var params: WindowManager.LayoutParams? = null

    private var phase by mutableStateOf(BubblePhase.IDLE)
    private var responseText by mutableStateOf("")
    private var bubbleScale by mutableStateOf(1f)
    // Amplitude micro normalisee (0f..1f), remontee en direct depuis
    // onRmsChanged pour faire bouger les barres au rythme de la voix reelle.
    private var micAmplitude by mutableStateOf(0f)

    // Ecran qui s'eteint (bouton power) = on considere que l'utilisateur a
    // quitte la bulle : sans ca, la bulle restait ouverte en arriere-plan et
    // "reapparaissait" avec l'ancienne reponse/etat au reveil du telephone.
    private val screenOffReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_SCREEN_OFF) {
                collapseToIdle()
            }
        }
    }

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private lateinit var settingsStore: SettingsStore
    private lateinit var repository: GeminiRepository
    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())

    // Barge-in : pendant que Nova parle (TTS), on ecoute en passif pour
    // detecter si l'utilisateur reprend la parole, afin de la couper et de
    // repasser directement en ecoute. Recognizer separe de "speechRecognizer"
    // pour ne jamais interferer avec une vraie session d'ecoute en cours.
    private var isTtsSpeaking = false
    private var bargeInRecognizer: SpeechRecognizer? = null
    private var bargeInJob: Job? = null

    // Job de la requete Gemini en cours (ecoute -> reflexion -> reponse).
    // Sans ca, fermer la bulle pendant la "reflexion" (ex: toucher a cote pour
    // l'enlever) ne faisait qu'IDLE l'etat le temps que le reseau reponde :
    // la coroutine finissait quand meme par forcer phase = REPLY et rouvrir
    // la fenetre d'un coup, sans aucune action de l'utilisateur. C'etait le
    // bug de la bulle qui "revient toute seule" plusieurs fois de suite.
    private var requestJob: Job? = null

    // Garde-fou de securite : si jamais aucun callback du SpeechRecognizer
    // ne se declenche (telephone lent, service vocal qui ne repond pas...),
    // la bulle restait bloquee en ecoute pour toujours. Un geste d'assistant
    // suivant etait alors ignore (voir lastListenLaunchAt plus bas), ce qui
    // donnait l'impression que "ca marche une fois sur deux". Ce job force
    // un retour a un etat propre si rien ne se passe au bout de 12s.
    private var listenWatchdogJob: Job? = null

    // Horodatage du dernier lancement d'ecoute effectivement traite. On ne
    // se base plus sur "phase" pour filtrer les doublons de geste (certains
    // telephones, notamment MIUI, redeclenchent le geste assistant deux fois
    // de suite tres vite) : se baser sur "phase" pouvait bloquer DEFINITIVEMENT
    // tout futur appui si la bulle restait coincee en LISTENING suite a un
    // bug transitoire. Un simple anti-rebond temporel est plus sur.
    private var lastListenLaunchAt = 0L

    companion object {
        const val CHANNEL_ID = "nova_bubble_channel"
        const val NOTIF_ID = 4201
        const val ACTION_STOP = "com.lucas.nova.bubble.STOP"
        const val ACTION_LAUNCH_LISTENING = "com.lucas.nova.bubble.LAUNCH_LISTENING"
    }

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.CREATED

        // Obligatoire des le debut : un service demarre en foreground DOIT appeler
        // startForeground() rapidement, meme s'il s'arrete juste apres, sous peine
        // de plantage systeme (ForegroundServiceDidNotStartInTimeException).
        startForegroundWithNotification()

        if (!android.provider.Settings.canDrawOverlays(this)) {
            // La permission "Afficher par-dessus les autres applis" a ete
            // retiree depuis la premiere activation : on ne peut pas dessiner
            // la bulle, on arrete proprement plutot que de planter.
            stopSelf()
            return
        }

        settingsStore = SettingsStore(applicationContext)
        repository = GeminiRepository(
            apiKeysProvider = { settingsStore.getApiKeys() },
            systemPromptProvider = { settingsStore.getSystemPrompt() }
        )

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        textToSpeech = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech?.language = Locale.FRANCE
                applySelectedVoice()
                textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        isTtsSpeaking = true
                        // Petit delai avant d'activer l'ecoute passive : ca evite
                        // que la toute premiere syllabe de Nova (avant que le haut-
                        // parleur et le micro "s'accordent") ne se declenche elle-meme.
                        bargeInJob?.cancel()
                        bargeInJob = serviceScope.launch {
                            delay(500)
                            if (isTtsSpeaking) startBargeInListener()
                        }
                    }

                    override fun onDone(utteranceId: String?) {
                        isTtsSpeaking = false
                        bargeInJob?.cancel()
                        stopBargeInListener()
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        isTtsSpeaking = false
                        bargeInJob?.cancel()
                        stopBargeInListener()
                    }
                })
            }
        }

        setupOverlayView()
        registerReceiver(screenOffReceiver, IntentFilter(Intent.ACTION_SCREEN_OFF))

        lifecycleRegistry.currentState = Lifecycle.State.RESUMED
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopSelf()
            ACTION_LAUNCH_LISTENING -> {
                // Declenche par le geste d'assistant systeme (NovaVoiceInteractionSession) :
                // on ouvre directement la bulle en mode ecoute, comme un vrai assistant.
                // Certains telephones (MIUI notamment) redeclenchent parfois ce geste
                // deux fois de suite tres rapidement : on ignore le doublon avec un
                // anti-rebond de 700ms base sur le temps, PAS sur "phase". L'ancienne
                // version bloquait tout nouvel appui tant que phase == LISTENING : si
                // une ecoute restait coincee (bug transitoire du micro), le geste
                // suivant ne faisait plus rien du tout, ce qui donnait l'impression
                // que la bulle "marchait une fois sur deux".
                val now = System.currentTimeMillis()
                if (composeView != null && now - lastListenLaunchAt > 700) {
                    lastListenLaunchAt = now
                    startListening()
                }
            }
        }
        return START_STICKY
    }

    private fun startForegroundWithNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Bulle Nova",
                NotificationManager.IMPORTANCE_MIN
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val openAppIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Nova est active")
            .setContentText("La bulle assistant est disponible par-dessus tes applications.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openAppIntent)
            .setOngoing(true)
            .build()

        startForeground(NOTIF_ID, notification)
    }

    private fun setupOverlayView() {
        val view = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@BubbleService)
            setViewTreeSavedStateRegistryOwner(this@BubbleService)
            setViewTreeViewModelStoreOwner(this@BubbleService)
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)

            setContent {
                NovaTheme {
                    BubbleOverlayContent(
                        phase = phase,
                        responseText = responseText,
                        scale = bubbleScale,
                        amplitude = micAmplitude,
                        onMicTap = { startListening() },
                        onSend = { text -> sendTypedMessage(text) },
                        onClose = { collapseToIdle() }
                    )
                }
            }
        }
        composeView = view

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        // Fenetre PLEIN ECRAN (contrairement a l'ancienne version qui etait
        // une petite fenetre "wrap content" positionnee en haut a gauche).
        // Le contenu Compose se charge lui-meme d'ancrer la bulle en bas et
        // de laisser le reste transparent. Ca permet a la fois la fermeture
        // au toucher en dehors de la bulle, et la remontee au-dessus du clavier.
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            layoutType,
            idleFlags(),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        params = lp

        windowManager.addView(view, lp)
    }

    /** Fenetre inactive : ni tactile ni focusable, pour ne jamais gener les
     * autres applis quand la bulle n'est pas affichee. */
    private fun idleFlags(): Int =
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN

    /** Bulle affichee mais pas de champ de saisie actif (ecoute/reflexion) :
     * tactile pour capter le toucher "fermer", mais pas focusable pour ne
     * pas voler le clavier. */
    private fun activeFlags(): Int =
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN

    /** Etat reponse : le champ de saisie doit pouvoir recevoir le clavier. */
    private fun focusableFlags(): Int =
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN

    private fun updateWindowFlags(flags: Int) {
        val lp = params ?: return
        lp.flags = flags
        composeView?.let {
            try {
                windowManager.updateViewLayout(it, lp)
            } catch (e: Exception) {
                // la vue peut avoir ete retiree entre-temps, rien a faire
            }
        }
    }

    /** Applique la voix choisie dans les reglages (si elle existe encore
     * parmi les voix disponibles sur ce telephone), sinon garde la voix
     * francaise par defaut du systeme. */
    private fun applySelectedVoice() {
        val savedName = settingsStore.getVoiceName() ?: return
        val match = textToSpeech?.voices?.firstOrNull { it.name == savedName }
        if (match != null) {
            textToSpeech?.voice = match
        }
    }

    /**
     * Ecoute passive pendant que Nova parle : des que l'utilisateur recommence
     * a parler par-dessus elle, on coupe la voix et on bascule directement en
     * vraie ecoute (barge-in), sans qu'il ait besoin de retoucher le micro.
     *
     * Limite connue : ceci s'appuie sur l'annulation d'echo materielle du
     * telephone (le micro "VOICE_RECOGNITION" beneficie generalement d'un
     * echo canceller quand disponible). Sur un telephone sans cette fonction
     * materielle, Nova peut parfois se couper elle-meme en s'entendant parler
     * — retoucher le micro reste alors le moyen fiable de relancer l'ecoute.
     */
    private fun startBargeInListener() {
        if (!isTtsSpeaking || phase != BubblePhase.REPLY) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return

        stopBargeInListener()
        bargeInRecognizer = NovaSpeech.createRecognizer(this)?.apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(bundle: android.os.Bundle?) {}
                override fun onBeginningOfSpeech() {
                    // L'utilisateur reparle : coupe Nova et repart en ecoute
                    // normale tout de suite (le vrai SpeechRecognizer prend le
                    // relais dans startListening(), qui coupe aussi le TTS).
                    stopBargeInListener()
                    startListening()
                }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    // Le recognizer passif se coupe seul au bout de quelques
                    // secondes de silence : on le relance tant que Nova parle
                    // toujours, pour rester a l'ecoute pendant toute la reponse.
                    bargeInRecognizer = null
                    if (isTtsSpeaking) startBargeInListener()
                }
                override fun onResults(results: android.os.Bundle?) {
                    bargeInRecognizer = null
                    if (isTtsSpeaking) startBargeInListener()
                }
                override fun onPartialResults(partialResults: android.os.Bundle?) {}
                override fun onEvent(eventType: Int, bundle: android.os.Bundle?) {}
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            }
            startListening(intent)
        }
    }

    private fun stopBargeInListener() {
        bargeInRecognizer?.let {
            try {
                it.cancel()
                it.destroy()
            } catch (e: Exception) {
                // recognizer deja detruit/en erreur, rien a faire
            }
        }
        bargeInRecognizer = null
    }

    // Reessai automatique unique sur une erreur transitoire (reseau, serveur
    // occupe) avant d'afficher un message d'echec a l'utilisateur — evite le
    // "je n'ai pas bien entendu" qui apparaissait parfois pour une simple
    // coupure reseau passagere plutot qu'un vrai probleme d'ecoute.
    private var autoRetried = false

    private fun startListening() {
        bubbleScale = settingsStore.getBubbleScale()

        // Reappuyer sur le micro pendant que Nova parle encore doit couper
        // la voix tout de suite : sinon le micro captait la propre voix de
        // Nova en train de finir sa phrase (auto-ecoute/echo).
        isTtsSpeaking = false
        bargeInJob?.cancel()
        stopBargeInListener()
        textToSpeech?.stop()
        micAmplitude = 0f
        autoRetried = false

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            responseText = "La reconnaissance vocale n'est pas disponible sur ce telephone."
            phase = BubblePhase.REPLY
            updateWindowFlags(focusableFlags())
            return
        }

        // Une nouvelle ecoute annule toute requete Gemini encore en vol issue
        // d'un echange precedent, pour ne jamais laisser une vieille reponse
        // ecraser l'etat courant plus tard.
        requestJob?.cancel()

        phase = BubblePhase.LISTENING
        updateWindowFlags(activeFlags())

        // Filet de securite : si aucun callback (onResults/onError) n'arrive
        // dans les 12s (service vocal du telephone qui ne repond plus), on
        // force un retour a un etat propre au lieu de laisser la bulle
        // bloquee indefiniment en "ecoute" — c'est ce blocage silencieux qui
        // faisait qu'un geste d'assistant suivant semblait ne "rien faire"
        // une fois sur deux. On ne surveille QUE la phase LISTENING : la
        // phase THINKING a son propre delai (requete Gemini, jusqu'a 60s),
        // gere par requestJob, donc on ne doit pas la couper trop tot ici.
        listenWatchdogJob?.cancel()
        listenWatchdogJob = serviceScope.launch {
            delay(12_000)
            if (phase == BubblePhase.LISTENING) {
                try { speechRecognizer?.cancel() } catch (e: Exception) { /* deja arrete */ }
                micAmplitude = 0f
                responseText = "Je n'ai pas bien entendu, touche le micro pour reessayer."
                phase = BubblePhase.REPLY
                updateWindowFlags(focusableFlags())
            }
        }

        beginRecognition()
    }

    private fun beginRecognition() {
        speechRecognizer?.destroy()
        val newRecognizer = NovaSpeech.createRecognizer(this)
        if (newRecognizer == null) {
            // Reconnaissance vocale indisponible sur ce telephone : meme
            // traitement que les autres echecs de demarrage, jamais de crash.
            listenWatchdogJob?.cancel()
            micAmplitude = 0f
            responseText = "La reconnaissance vocale n'est pas disponible sur ce telephone.\n\nMoteur utilise : ${NovaSpeech.lastEngineInfo}"
            phase = BubblePhase.REPLY
            updateWindowFlags(focusableFlags())
            return
        }
        try {
            speechRecognizer = newRecognizer.apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(bundle: android.os.Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {
                        // rmsdB va grosso modo de ~0 (silence) a ~10+ (voix forte)
                        // selon les telephones : on normalise sur 0f..1f pour que
                        // les barres de la bulle suivent le volume reel de la voix.
                        micAmplitude = (rmsdB / 10f).coerceIn(0f, 1f)
                    }
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {
                        micAmplitude = 0f
                        phase = BubblePhase.THINKING
                    }

                    override fun onError(error: Int) {
                        // On elargit les erreurs "transitoires" au-dela du reseau :
                        // ERROR_SPEECH_TIMEOUT et ERROR_NO_MATCH arrivent tres
                        // souvent juste parce que le micro/reconnaisseur n'a pas
                        // eu le temps de "s'echauffer" au tout premier lancement
                        // (surtout via le geste d'assistant systeme). Plutot que
                        // d'afficher tout de suite "je n'ai pas bien entendu" de
                        // facon aleatoire, on retente une fois, silencieusement.
                        // On elargit les erreurs "transitoires" au-dela du reseau :
                        // ERROR_SPEECH_TIMEOUT et ERROR_NO_MATCH arrivent tres
                        // souvent juste parce que le micro/reconnaisseur n'a pas
                        // eu le temps de "s'echauffer" au tout premier lancement
                        // (surtout via le geste d'assistant systeme). Le code 11
                        // (ERROR_SERVER_DISCONNECTED) est egalement tres frequent
                        // et presque toujours resolu par une simple reconnexion :
                        // il ne merite pas plus qu'un message d'erreur bloquant.
                        // Plutot que d'afficher tout de suite "je n'ai pas bien
                        // entendu" de facon aleatoire, on retente une fois,
                        // silencieusement.
                        val transient = error == SpeechRecognizer.ERROR_NETWORK ||
                            error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ||
                            error == SpeechRecognizer.ERROR_SERVER ||
                            error == SpeechRecognizer.ERROR_SERVER_DISCONNECTED ||
                            error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ||
                            error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ||
                            error == SpeechRecognizer.ERROR_NO_MATCH

                        if (transient && !autoRetried) {
                            autoRetried = true
                            micAmplitude = 0f
                            phase = BubblePhase.LISTENING
                            // Petit delai avant de recreer le SpeechRecognizer :
                            // le detruire puis le recreer dans la meme frame
                            // (sans laisser le service de reconnaissance liberer
                            // ses ressources) provoquait parfois un echec
                            // immediat sur certains telephones (notamment
                            // MIUI), ce qui rendait ce reessai automatique
                            // inutile en pratique.
                            serviceScope.launch {
                                delay(350)
                                if (phase == BubblePhase.LISTENING) {
                                    beginRecognition()
                                }
                            }
                            return
                        }

                        listenWatchdogJob?.cancel()
                        micAmplitude = 0f
                        // Detruit explicitement l'instance en echec definitif
                        // (pas seulement au prochain beginRecognition()) : tant
                        // qu'un SpeechRecognizer casse reste reference, les
                        // barres d'animation du micro peuvent rester figees si
                        // un evenement tardif du moteur systeme arrive apres
                        // coup. On repart d'une reference nulle et propre.
                        try { speechRecognizer?.destroy() } catch (e: Exception) { /* deja detruit */ }
                        speechRecognizer = null
                        // Le code technique (error) ET le moteur reellement
                        // utilise (voir NovaSpeech.lastEngineInfo) sont
                        // ajoutes pour permettre un diagnostic precis en cas
                        // de nouvel echec, sans avoir besoin de brancher le
                        // telephone pour lire les logs.
                        val engineInfo = "\n\nMoteur utilise : ${NovaSpeech.lastEngineInfo}"
                        responseText = when (error) {
                            SpeechRecognizer.ERROR_NO_MATCH ->
                                "Je n'ai pas bien compris, touche le micro pour reessayer. (code $error)$engineInfo"
                            SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                                "Je n'ai rien entendu, touche le micro pour reessayer. (code $error)$engineInfo"
                            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                                "Nova a besoin de l'acces au micro dans les reglages du telephone. (code $error)$engineInfo"
                            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                                "Probleme de connexion, touche le micro pour reessayer. (code $error)$engineInfo"
                            SpeechRecognizer.ERROR_SERVER_DISCONNECTED ->
                                "Le service vocal s'est deconnecte, touche le micro pour reessayer. (code $error)$engineInfo"
                            else ->
                                "Je n'ai pas bien entendu, touche le micro pour reessayer. (code $error)$engineInfo"
                        }
                        phase = BubblePhase.REPLY
                        updateWindowFlags(focusableFlags())
                    }

                    override fun onResults(results: android.os.Bundle?) {
                        listenWatchdogJob?.cancel()
                        micAmplitude = 0f
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val spokenText = matches?.firstOrNull().orEmpty()
                        if (spokenText.isBlank()) {
                            responseText = "Je n'ai rien entendu, touche le micro pour reessayer."
                            phase = BubblePhase.REPLY
                            updateWindowFlags(focusableFlags())
                        } else {
                            askGemini(spokenText)
                        }
                    }

                    override fun onPartialResults(partialResults: android.os.Bundle?) {}
                    override fun onEvent(eventType: Int, bundle: android.os.Bundle?) {}
                })

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
                    // Laisse plus de temps avant de couper l'ecoute sur un silence
                    // bref (l'utilisateur qui reflechit une seconde en parlant) :
                    // c'etait la cause la plus frequente du "je n'ai pas bien
                    // entendu" declenche au mauvais moment, de facon aleatoire.
                    // 5000ms (au lieu de 1500ms) : certaines surcouches
                    // constructeur (HyperOS/MIUI sur les Redmi/Xiaomi
                    // notamment) coupent le SpeechRecognizer bien plus tot
                    // que la valeur demandee si elle est trop courte.
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 5000)
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 5000)
                    // ATTENTION : cet extra ne "tolere" PAS un silence de
                    // cette duree (c'est le role de COMPLETE_SILENCE plus
                    // haut) — il oblige le moteur a garder l'enregistrement
                    // ouvert au minimum ce temps-la, quoi qu'il arrive. Une
                    // valeur de 15s forcait donc 15 secondes d'enregistrement
                    // OBLIGATOIRE avant que le moteur ait le droit de
                    // finaliser, meme pour une phrase courte, ce qui cassait
                    // la transcription (NO_MATCH/timeout) alors que le micro
                    // captait pourtant bien le son (d'ou les barres qui
                    // bougeaient normalement). 2s suffit largement comme
                    // plancher.
                    putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 2_000)
                }
                startListening(intent)
            }
        } catch (e: Exception) {
            // Le service de reconnaissance vocale du telephone peut refuser de
            // demarrer (permission retiree entre-temps, service occupe...) :
            // avant, cette exception non rattrapee laissait la bulle bloquee
            // en LISTENING pour toujours. On revient proprement a un etat
            // affichable au lieu de planter/rester coincee.
            listenWatchdogJob?.cancel()
            micAmplitude = 0f
            responseText = "Je n'ai pas bien entendu, touche le micro pour reessayer."
            phase = BubblePhase.REPLY
            updateWindowFlags(focusableFlags())
        }
    }

    private fun sendTypedMessage(text: String) {
        isTtsSpeaking = false
        bargeInJob?.cancel()
        stopBargeInListener()
        textToSpeech?.stop()
        phase = BubblePhase.THINKING
        askGemini(text)
    }

    private fun askGemini(text: String) {
        requestJob = serviceScope.launch {
            when (val result = repository.sendMessage(emptyList<ChatMessage>(), text)) {
                is GeminiRepository.Result.Success -> {
                    responseText = result.text
                    applySelectedVoice()
                    textToSpeech?.speak(result.text, TextToSpeech.QUEUE_FLUSH, null, "nova_reply")
                }
                is GeminiRepository.Result.Failure -> {
                    responseText = result.message
                }
            }
            // Si l'utilisateur a ferme la bulle pendant que Gemini reflechissait,
            // ce job a ete annule et on ne doit surtout pas la rouvrir tout seul.
            if (!isActive) return@launch
            phase = BubblePhase.REPLY
            updateWindowFlags(focusableFlags())
        }
    }

    private fun collapseToIdle() {
        // Fermer la bulle (toucher l'ecran d'accueil) doit aussi couper la
        // voix en cours et annuler toute requete Gemini encore en attente,
        // sinon sa reponse finit par arriver "toute seule" et rouvre la bulle.
        requestJob?.cancel()
        listenWatchdogJob?.cancel()
        isTtsSpeaking = false
        bargeInJob?.cancel()
        stopBargeInListener()
        textToSpeech?.stop()
        // destroy() plutot que cancel() : on veut repartir d'une base
        // totalement propre au prochain lancement. Un recognizer juste
        // "cancel" pouvait rester dans un etat intermediaire cote service
        // systeme, ce qui provoquait un echec immediat (sans meme passer par
        // l'ecoute) au geste d'assistant suivant.
        speechRecognizer?.destroy()
        speechRecognizer = null
        phase = BubblePhase.IDLE
        responseText = ""
        micAmplitude = 0f
        updateWindowFlags(idleFlags())
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        requestJob?.cancel()
        listenWatchdogJob?.cancel()
        bargeInJob?.cancel()
        stopBargeInListener()
        speechRecognizer?.destroy()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        try {
            unregisterReceiver(screenOffReceiver)
        } catch (e: Exception) {
            // deja desenregistre (ex: onCreate a quitte tot faute de permission overlay)
        }
        composeView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                // vue deja retiree
            }
        }
        serviceScope.cancel()
        super.onDestroy()
    }
}
