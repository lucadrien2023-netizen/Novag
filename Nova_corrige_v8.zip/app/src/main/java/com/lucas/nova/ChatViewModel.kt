package com.lucas.nova

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lucas.nova.data.ChatMessage
import com.lucas.nova.data.ConversationMeta
import com.lucas.nova.data.ConversationStore
import com.lucas.nova.data.GeminiRepository
import com.lucas.nova.data.NovaModel
import com.lucas.nova.data.SettingsStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class ChatViewModel(
    private val appContext: Context,
    private val settingsStore: SettingsStore,
    private val conversationStore: ConversationStore
) : ViewModel() {

    private val repository = GeminiRepository(
        apiKeysProvider = { settingsStore.getApiKeys() },
        systemPromptProvider = { settingsStore.getSystemPrompt() },
        modelProvider = { settingsStore.getSelectedModel() }
    ).apply {
        imagesDir = File(appContext.filesDir, "chat_images").absolutePath
    }

    val messages = mutableStateListOf<ChatMessage>()
    val isTyping = mutableStateOf(false)

    val apiKeyInput = mutableStateOf(settingsStore.getApiKeys().joinToString(", "))
    val assistantName = mutableStateOf(settingsStore.getAssistantName())
    val userName = mutableStateOf(settingsStore.getUserName().ifBlank { "Toi" })
    val systemPrompt = mutableStateOf(settingsStore.getSystemPrompt())
    // L'ecran de bienvenue (nom + cle API) s'occupe desormais de la toute
    // premiere configuration : on n'ouvre plus les Reglages tout seul juste
    // parce que la cle API est vide.
    val showSettings = mutableStateOf(false)

    // Menu cache (tap discret sur "Nova") : choix du modele, debloque selon
    // les cles API deja renseignees.
    val showModelPicker = mutableStateOf(false)
    val selectedModel = mutableStateOf(settingsStore.getSelectedModel())
    val unlockedModels = mutableStateListOf<NovaModel>().apply { addAll(settingsStore.unlockedModels()) }

    val conversations = mutableStateListOf<ConversationMeta>()
    private var currentConversationId: String = conversationStore.newConversationId()

    val bubbleEnabled = mutableStateOf(settingsStore.getBubbleEnabled())

    init {
        refreshConversations()
    }

    fun setBubbleEnabledPreference(enabled: Boolean) {
        bubbleEnabled.value = enabled
        settingsStore.setBubbleEnabled(enabled)
    }

    private fun refreshConversations() {
        conversations.clear()
        conversations.addAll(conversationStore.listConversations())
    }

    fun saveSettings(apiKey: String, name: String, prompt: String) {
        // Plusieurs cles peuvent etre collees, separees par des virgules :
        // GeminiRepository bascule automatiquement sur la suivante des
        // qu'une cle atteint sa limite gratuite (429).
        val keys = apiKey.split(",").map { it.trim() }.filter { it.isNotBlank() }
        settingsStore.setApiKeys(keys)
        settingsStore.setAssistantName(name.trim().ifBlank { SettingsStore.DEFAULT_NAME })
        settingsStore.setSystemPrompt(prompt.trim().ifBlank { SettingsStore.DEFAULT_SYSTEM_PROMPT })
        apiKeyInput.value = apiKey.trim()
        assistantName.value = settingsStore.getAssistantName()
        systemPrompt.value = settingsStore.getSystemPrompt()
        showSettings.value = false
        refreshUnlockedModels()
    }

    /** Rafraichit les modeles debloques (appele quand la cle API change). */

    private fun refreshUnlockedModels() {
        unlockedModels.clear()
        unlockedModels.addAll(settingsStore.unlockedModels())
        // Si le modele actuellement selectionne vient d'etre verrouille
        // (cle retiree), on retombe sur le modele texte par defaut.
        if (unlockedModels.none { it.id == selectedModel.value }) {
            selectModel(SettingsStore.DEFAULT_MODEL_ID)
        }
    }

    fun selectModel(modelId: String) {
        selectedModel.value = modelId
        settingsStore.setSelectedModel(modelId)
        showModelPicker.value = false
    }

    fun startNewConversation() {
        messages.clear()
        currentConversationId = conversationStore.newConversationId()
    }

    fun openConversation(id: String) {
        currentConversationId = id
        messages.clear()
        messages.addAll(conversationStore.loadMessages(id))
    }

    fun togglePin(id: String) {
        conversationStore.togglePin(id)
        refreshConversations()
    }

    fun renameConversation(id: String, newTitle: String) {
        conversationStore.renameConversation(id, newTitle)
        refreshConversations()
    }

    fun deleteConversation(id: String) {
        conversationStore.deleteConversation(id)
        if (id == currentConversationId) {
            startNewConversation()
        }
        refreshConversations()
    }

    fun deleteAllConversations() {
        conversationStore.deleteAll()
        startNewConversation()
        refreshConversations()
    }

    /**
     * Detecte si le message ressemble a une demande de generation d'image,
     * pour basculer automatiquement sur Nano Banana Pro sans que l'humain
     * ait besoin d'aller le selectionner a la main dans le menu cache
     * avant chaque demande. Liste volontairement large mais simple
     * (mots-cles francais courants), pas une vraie comprehension du texte :
     * en cas de doute, on prefere laisser passer vers le modele texte
     * normal plutot que de detourner un message qui n'a rien a voir.
     */
    private fun looksLikeImageRequest(text: String): Boolean {
        val normalized = text.lowercase()
        val triggers = listOf(
            "genere une image", "génère une image", "generer une image", "générer une image",
            "genere-moi une image", "génère-moi une image",
            "cree une image", "crée une image", "creer une image", "créer une image",
            "cree-moi une image", "crée-moi une image",
            "fais une image", "fais-moi une image",
            "dessine", "dessine-moi",
            "genere une photo", "génère une photo", "cree une photo", "crée une photo",
            "image de ", "photo de ", "illustration de "
        )
        return triggers.any { normalized.contains(it) }
    }

    fun sendMessage(text: String, imageUris: List<Uri> = emptyList()) {
        if (text.isBlank() && imageUris.isEmpty()) return

        val history = messages.toList()
        val explicitlyImageModel = SettingsStore.AVAILABLE_MODELS
            .firstOrNull { it.id == settingsStore.getSelectedModel() }?.generatesImages == true
        val isImageModel = explicitlyImageModel || looksLikeImageRequest(text)

        viewModelScope.launch {
            try {
                // On copie les photos choisies dans le stockage interne de
                // l'appli AVANT de les ajouter au message : l'URI donnee par
                // le picker systeme peut perdre son autorisation de lecture
                // des que l'appli est fermee.
                val imagePaths = imageUris.mapNotNull { persistImageLocally(it) }

                messages.add(ChatMessage(text = text, isUser = true, imagePaths = imagePaths))
                isTyping.value = true

                val textForModel = text.ifBlank { if (imagePaths.isNotEmpty()) "Voici une photo." else text }

                if (isImageModel) {
                    // Le modele d'image (gemini-3-pro-image) n'est pas
                    // conversationnel ici : on envoie juste le texte du
                    // message comme prompt, sur ":generateContent" (voir
                    // GeminiRepository.generateImage).
                    val imageModelId = SettingsStore.AVAILABLE_MODELS.first { it.generatesImages }.id
                    when (val result = repository.generateImage(textForModel, modelOverride = imageModelId)) {
                        is GeminiRepository.Result.Success -> {
                            messages.add(ChatMessage(text = result.text, isUser = false, imagePaths = result.imagePaths))
                        }
                        is GeminiRepository.Result.Failure -> {
                            messages.add(ChatMessage(text = result.message, isUser = false, isError = true))
                        }
                    }
                    conversationStore.saveConversation(currentConversationId, messages.toList())
                    refreshConversations()
                    isTyping.value = false
                } else {
                    // Reponse texte : on streame, en mettant a jour un seul
                    // message assistant au fur et a mesure des morceaux
                    // recus, pour un ressenti beaucoup plus rapide qu'en
                    // attendant la reponse complete.
                    var placeholderIndex = -1
                    repository.sendMessageStream(history, textForModel, imagePaths)
                        .collect { event ->
                            when (event) {
                                is GeminiRepository.StreamEvent.Partial -> {
                                    isTyping.value = false
                                    if (placeholderIndex == -1) {
                                        messages.add(ChatMessage(text = event.textSoFar, isUser = false))
                                        placeholderIndex = messages.lastIndex
                                    } else {
                                        messages[placeholderIndex] = messages[placeholderIndex].copy(text = event.textSoFar)
                                    }
                                }
                                is GeminiRepository.StreamEvent.Done -> {
                                    isTyping.value = false
                                    if (placeholderIndex == -1) {
                                        messages.add(ChatMessage(text = event.finalText, isUser = false))
                                    } else {
                                        messages[placeholderIndex] = messages[placeholderIndex].copy(text = event.finalText)
                                    }
                                    conversationStore.saveConversation(currentConversationId, messages.toList())
                                    refreshConversations()
                                }
                                is GeminiRepository.StreamEvent.Error -> {
                                    isTyping.value = false
                                    if (placeholderIndex != -1) {
                                        messages.removeAt(placeholderIndex)
                                    }
                                    messages.add(ChatMessage(text = event.message, isUser = false, isError = true))
                                    conversationStore.saveConversation(currentConversationId, messages.toList())
                                    refreshConversations()
                                }
                            }
                        }
                }
            } catch (e: Exception) {
                // Filet de securite : avant, une exception inattendue ici
                // laissait "isTyping" bloque a "true" pour toujours.
                messages.add(
                    ChatMessage(
                        text = "Une erreur inattendue est survenue. Reessaie.",
                        isUser = false,
                        isError = true
                    )
                )
                isTyping.value = false
            }
        }
    }

    /** Renvoie exactement la meme question (bulle utilisateur ou assistant,
     * via le menu contextuel "Renvoyer la question"). */
    fun resend(text: String) {
        if (text.isNotBlank()) sendMessage(text)
    }

    /** Supprime une photo jointe a un message deja envoye (avant ou apres
     * reception de la reponse), a la demande de l'utilisateur depuis
     * l'aperçu plein ecran. */
    fun removeImageFromMessage(messageId: Long, imagePath: String) {
        val index = messages.indexOfFirst { it.id == messageId }
        if (index == -1) return
        val msg = messages[index]
        messages[index] = msg.copy(imagePaths = msg.imagePaths.filterNot { it == imagePath })
        conversationStore.saveConversation(currentConversationId, messages.toList())
        File(imagePath).let { if (it.exists()) runCatching { it.delete() } }
    }

    /** Copie l'image choisie dans le picker vers le stockage prive de
     * l'appli (dossier "chat_images") et renvoie le chemin local absolu,
     * ou null si la copie a echoue. */
    private suspend fun persistImageLocally(uri: Uri): String? = withContext(Dispatchers.IO) {
        runCatching {
            val dir = File(appContext.filesDir, "chat_images").apply { mkdirs() }
            val dest = File(dir, "${UUID.randomUUID()}.jpg")
            appContext.contentResolver.openInputStream(uri)?.use { input ->
                dest.outputStream().use { output -> input.copyTo(output) }
            }
            dest.absolutePath
        }.getOrNull()
    }
}
