package com.lucas.nova.bubble

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lucas.nova.ui.theme.BubbleGlassStrong
import com.lucas.nova.ui.theme.NovaBlue
import com.lucas.nova.ui.theme.NovaPink
import com.lucas.nova.ui.theme.NovaPurple
import com.lucas.nova.ui.theme.TextPrimary
import com.lucas.nova.ui.theme.TextSecondary

private val NovaEase = CubicBezierEasing(0.25f, 1f, 0.3f, 1f)

/**
 * Conteneur PLEIN ECRAN de la bulle assistant : contrairement a l'ancienne
 * version (petite fenetre qui se baladait en haut de l'ecran), la fenetre
 * couvre maintenant tout l'ecran, mais seule la bulle en bas est visible —
 * le reste sert de zone transparente qui referme la bulle au toucher, comme
 * un assistant vocal classique. La bulle remonte automatiquement au-dessus
 * du clavier grace a imePadding().
 */
@Composable
fun BubbleOverlayContent(
    phase: BubblePhase,
    responseText: String,
    scale: Float,
    amplitude: Float = 0f,
    onMicTap: () -> Unit,
    onSend: (String) -> Unit,
    onClose: () -> Unit
) {
    val visible = phase != BubblePhase.IDLE

    Box(
        modifier = Modifier
            .fillMaxSize()
            // Zone transparente : un toucher n'importe ou en dehors de la bulle la referme.
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) {
                if (visible) onClose()
            },
        contentAlignment = Alignment.BottomCenter
    ) {
        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(tween(280, easing = NovaEase)) + slideInVertically(tween(320, easing = NovaEase)) { it / 3 },
            exit = fadeOut(tween(200)) + slideOutVertically(tween(220, easing = NovaEase)) { it / 3 },
            modifier = Modifier
                .imePadding()
                .navigationBarsPadding()
                .padding(bottom = 22.dp)
        ) {
            BubbleCard(phase = phase, responseText = responseText, scale = scale, amplitude = amplitude, onMicTap = onMicTap, onSend = onSend, onClose = onClose)
        }
    }
}

@Composable
private fun BubbleCard(
    phase: BubblePhase,
    responseText: String,
    scale: Float,
    amplitude: Float,
    onMicTap: () -> Unit,
    onSend: (String) -> Unit,
    onClose: () -> Unit
) {
    val targetWidth = when (phase) {
        BubblePhase.LISTENING -> 130.dp * scale
        BubblePhase.THINKING -> 84.dp * scale
        BubblePhase.REPLY -> 340.dp // largeur reelle bornee par fillMaxWidth ci-dessous
        BubblePhase.IDLE -> 0.dp
    }
    val targetHeight = when (phase) {
        BubblePhase.LISTENING -> 76.dp * scale
        BubblePhase.THINKING -> 84.dp * scale
        BubblePhase.REPLY -> 0.dp // wrap content
        BubblePhase.IDLE -> 0.dp
    }

    // Ressort plutot qu'un tween lineaire : la bulle "respire" en changeant de
    // taille au lieu de faire un mouvement mecanique, pour une sensation plus
    // fluide et organique entre les etats ecoute/reflexion/reponse.
    val sizeSpring = spring<Dp>(dampingRatio = 0.72f, stiffness = 340f)
    val animatedWidth by animateDpAsState(targetWidth, sizeSpring, label = "w")
    val animatedHeight by animateDpAsState(targetHeight, sizeSpring, label = "h")
    // 28dp pour la reponse (carte rectangulaire), mais un rayon enorme (999dp,
    // qu'on laisse Compose clamper a la moitie du plus petit cote) pour
    // l'ecoute/la reflexion : ca garantit un cercle parfait et fluide plutot
    // qu'un carre aux coins arrondis, quelle que soit l'echelle choisie.
    val radius = if (phase == BubblePhase.REPLY) 28.dp else 999.dp

    Box(
        modifier = Modifier
            .padding(horizontal = 16.dp)
            .let {
                if (phase == BubblePhase.REPLY) it.fillMaxWidth() else it.width(animatedWidth)
            }
            .let {
                if (phase == BubblePhase.REPLY) it else it.height(animatedHeight)
            }
            .shadow(24.dp, RoundedCornerShape(radius))
            .clip(RoundedCornerShape(radius))
            .background(BubbleGlassStrong)
            .border(1.dp, Color(0xCCFFFFFF), RoundedCornerShape(radius))
            // On absorbe le clic ici pour que toucher LA bulle ne la referme pas
            // (seule la zone en dehors, geree par le parent, la referme).
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) {},
        contentAlignment = if (phase == BubblePhase.REPLY) Alignment.TopStart else Alignment.Center
    ) {
        when (phase) {
            BubblePhase.LISTENING -> ListeningContent(scale, amplitude)
            BubblePhase.THINKING -> ThinkingContent(scale)
            BubblePhase.REPLY -> ReplyContent(
                responseText = responseText,
                onMicTap = onMicTap,
                onSend = onSend,
                onClose = onClose
            )
            BubblePhase.IDLE -> {}
        }
    }
}

/**
 * Barres reactives au volume reel de la voix (onRmsChanged du
 * SpeechRecognizer, normalise 0f..1f et remonte via "amplitude"), plutot
 * qu'une animation en boucle deconnectee de ce que dit l'utilisateur.
 * En silence (amplitude quasi nulle), une legere respiration douce evite
 * que les barres paraissent figees en attendant que la personne parle.
 */
@Composable
private fun ListeningContent(scale: Float, amplitude: Float) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp * scale)) {
        ListeningBar(baseHeight = 10.dp * scale, maxHeight = 26.dp * scale, amplitude = amplitude, weight = 0.75f)
        ListeningBar(baseHeight = 10.dp * scale, maxHeight = 38.dp * scale, amplitude = amplitude, weight = 1f)
        ListeningBar(baseHeight = 10.dp * scale, maxHeight = 26.dp * scale, amplitude = amplitude, weight = 0.85f)
    }
}

@Composable
private fun ListeningBar(baseHeight: Dp, maxHeight: Dp, amplitude: Float, weight: Float) {
    // Meme correction que DictationBar dans ChatScreen.kt : avant, cette
    // respiration decorative utilisait la MEME couleur que le vrai signal
    // audio, rendant impossible de distinguer "la bulle capte vraiment du
    // son" de "rien n'est capte, ceci est juste une decoration animee" --
    // exactement le faux signal qui a brouille le diagnostic du micro.
    val isRealSignal = amplitude >= 0.06f
    val transition = rememberInfiniteTransition(label = "idleBreath")
    val idlePulse by transition.animateFloat(
        initialValue = 0.12f,
        targetValue = 0.20f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "idlePulse"
    )
    val fraction = if (isRealSignal) (amplitude * weight).coerceIn(0f, 1f) else idlePulse
    val height by animateDpAsState(
        targetValue = baseHeight + (maxHeight - baseHeight) * fraction,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 700f),
        label = "barHeight"
    )
    val barColor by androidx.compose.animation.animateColorAsState(
        targetValue = if (isRealSignal) NovaBlue else Color(0xFFC7C7CE),
        label = "barColor"
    )
    Box(
        modifier = Modifier
            .width(4.dp)
            .height(height)
            .clip(RoundedCornerShape(4.dp))
            .background(barColor)
    )
}

/**
 * Trois points qui pulsent en degrade, coherents avec le TypingIndicator du
 * chat, plutot qu'un simple rond de chargement generique.
 */
@Composable
private fun ThinkingContent(scale: Float) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp * scale)) {
        repeat(3) { index ->
            ThinkingDot(size = 9.dp * scale, delayMillis = index * 160)
        }
    }
}

@Composable
private fun ThinkingDot(size: Dp, delayMillis: Int) {
    val transition = rememberInfiniteTransition(label = "thinkDot")
    val dotScale by transition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 560, delayMillis = delayMillis),
            repeatMode = RepeatMode.Reverse
        ),
        label = "thinkDotScale"
    )
    Box(
        modifier = Modifier
            .size(size)
            .graphicsLayer { scaleX = dotScale; scaleY = dotScale }
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(NovaPurple, NovaBlue)))
    )
}

@Composable
private fun ReplyContent(
    responseText: String,
    onMicTap: () -> Unit,
    onSend: (String) -> Unit,
    onClose: () -> Unit
) {
    var inputText by remember { mutableStateOf("") }

    Column(modifier = Modifier.padding(20.dp)) {
        AnimatedVisibility(visible = responseText.isNotBlank(), enter = fadeIn(tween(400, delayMillis = 150)), exit = fadeOut()) {
            Text(
                text = responseText,
                color = TextPrimary,
                fontSize = 16.sp,
                lineHeight = 22.sp,
                fontWeight = FontWeight.Normal,
                modifier = Modifier.padding(bottom = 15.dp)
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0x0D000000))
                .padding(start = 16.dp, top = 6.dp, bottom = 6.dp, end = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Écrire à Nova...", color = TextSecondary, fontSize = 16.sp) },
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 16.sp),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = androidx.compose.foundation.text.KeyboardActions(
                    onSend = {
                        if (inputText.isNotBlank()) {
                            onSend(inputText)
                            inputText = ""
                        }
                    }
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                    cursorColor = NovaBlue
                )
            )

            val actionInteraction = remember { MutableInteractionSource() }
            val actionPressed by actionInteraction.collectIsPressedAsState()
            val actionScale by animateFloatAsState(
                targetValue = if (actionPressed) 0.88f else 1f,
                animationSpec = spring(dampingRatio = 0.5f, stiffness = 600f),
                label = "bubbleActionScale"
            )
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .graphicsLayer { scaleX = actionScale; scaleY = actionScale }
                    .clip(CircleShape)
                    .background(
                        if (inputText.isNotBlank()) Brush.linearGradient(listOf(NovaPurple, NovaPink))
                        else Brush.linearGradient(listOf(Color(0xFFE4E4E9), Color(0xFFE4E4E9)))
                    )
                    .clickable(indication = null, interactionSource = actionInteraction) {
                        if (inputText.isNotBlank()) {
                            onSend(inputText)
                            inputText = ""
                        } else {
                            onMicTap()
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                if (inputText.isNotBlank()) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Envoyer", tint = Color.White, modifier = Modifier.size(19.dp))
                } else {
                    Icon(Icons.Filled.Mic, contentDescription = "Micro", tint = Color(0xFF8E8E93), modifier = Modifier.size(19.dp))
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            "toucher en dehors pour fermer",
            color = TextSecondary,
            fontSize = 11.sp,
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .padding(top = 4.dp)
        )
    }
}
