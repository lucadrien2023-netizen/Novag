package com.lucas.nova.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.lucas.nova.ChatViewModel
import com.lucas.nova.ui.theme.GlassBorder
import com.lucas.nova.ui.theme.MenuItemSurface
import com.lucas.nova.ui.theme.NovaBlue
import com.lucas.nova.ui.theme.NovaPink
import com.lucas.nova.ui.theme.NovaPurple
import com.lucas.nova.ui.theme.TextPrimary
import com.lucas.nova.ui.theme.TextSecondary
import com.lucas.nova.ui.theme.TextTertiary
import com.lucas.nova.util.NovaSpeech
import kotlinx.coroutines.launch

private val suggestions = listOf(
    "Résume-moi une actualité",
    "Aide-moi à rédiger un message",
    "Explique-moi un concept",
    "Donne-moi une idée de recette"
)

private val NovaEase = CubicBezierEasing(0.22f, 1f, 0.36f, 1f)

@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    isDefaultAssistant: Boolean = false,
    onRequestBubbleToggle: (Boolean) -> Unit = {},
    onRequestAssistantRole: () -> Unit = {}
) {
    val messages = viewModel.messages
    val isTyping by viewModel.isTyping
    val assistantName by viewModel.assistantName
    val userName by viewModel.userName
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScopeCompat()
    var historyVisible by remember { mutableStateOf(false) }
    var toastMessage by remember { mutableStateOf<String?>(null) }
    // Erreur du micro : AVANT, un simple toast qui disparaissait en 2.2s et
    // qui etait facile a manquer -- exactement ce qui rendait le diagnostic
    // du bug de reconnaissance vocale impossible sans brancher le telephone.
    // Maintenant une vraie boite de dialogue qui reste affichee jusqu'a ce
    // qu'on la ferme, avec le code d'erreur ET le moteur de reconnaissance
    // reellement utilise (voir NovaSpeech.lastEngineInfo).
    var micErrorMessage by remember { mutableStateOf<String?>(null) }
    // Aperçu plein ecran d'une photo (avant envoi, depuis la pilule de
    // saisie, OU deja envoyee, depuis une bulle de conversation). Le
    // messageId est null pour une photo pas encore envoyee : dans ce cas
    // "supprimer" enleve juste la photo de la selection en cours plutot que
    // d'appeler le ViewModel.
    var previewTarget by remember { mutableStateOf<ImagePreviewTarget?>(null) }
    // Photos en attente d'envoi : remontees ici (plutot que gardees dans
    // InputBar) pour que l'aperçu plein ecran puisse aussi les supprimer
    // avant l'envoi, pas seulement apres.
    var pendingImageUris by remember { mutableStateOf<List<Uri>>(emptyList()) }

    // Bug corrige : avant, CHAQUE changement (taille de la liste, isTyping)
    // relancait un scroll vers le bas meme si l'utilisateur avait remonte
    // pour relire un ancien message — d'ou l'impression que "la discussion
    // remonte toute seule" (en realite elle etait renvoyee tout en bas sans
    // arret). Desormais on ne force le defilement automatique que si
    // l'utilisateur etait DEJA en bas au moment ou un nouveau message
    // arrive ; sinon on laisse sa position tranquille et on affiche juste
    // le bouton "retour en bas".
    val isAtBottom by remember {
        derivedStateOf {
            val layoutInfo = listState.layoutInfo
            val lastVisible = layoutInfo.visibleItemsInfo.lastOrNull()
            val totalItems = layoutInfo.totalItemsCount
            lastVisible == null || lastVisible.index >= totalItems - 1
        }
    }

    LaunchedEffect(messages.size, isTyping) {
        if ((messages.isNotEmpty() || isTyping) && isAtBottom) {
            scope.launch {
                listState.animateScrollToItem((messages.size - 1 + if (isTyping) 1 else 0).coerceAtLeast(0))
            }
        }
    }

    fun scrollToBottom() {
        scope.launch {
            listState.animateScrollToItem((messages.size - 1 + if (isTyping) 1 else 0).coerceAtLeast(0))
        }
    }

    LaunchedEffect(toastMessage) {
        if (toastMessage != null) {
            kotlinx.coroutines.delay(2200)
            toastMessage = null
        }
    }

    fun showToast(msg: String) { toastMessage = msg }

    NovaBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                // S'adapte a l'encoche, la barre de statut, la barre de nav et le clavier
                // de n'importe quel telephone, plutot que des marges fixes.
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
        ) {
            TopBar(
                assistantName = assistantName,
                isTyping = isTyping,
                onHistoryClick = { historyVisible = true },
                onNewChat = { viewModel.startNewConversation() },
                onTitleClick = { viewModel.showModelPicker.value = true }
            )

            Box(modifier = Modifier.weight(1f)) {
                if (messages.isEmpty() && !isTyping) {
                    EmptyState(assistantName = assistantName, onSuggestionClick = { viewModel.sendMessage(it) })
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 16.dp)
                    ) {
                        items(messages, key = { it.id }) { msg ->
                            AnimatedMessageItem {
                                MessageBubble(
                                    message = msg,
                                    onImageClick = { path ->
                                        previewTarget = ImagePreviewTarget(path = path, messageId = msg.id)
                                    },
                                    onResend = { text -> viewModel.resend(text) }
                                )
                            }
                        }
                        if (isTyping) {
                            item(key = "typing") {
                                Row(modifier = Modifier.padding(start = 14.dp)) {
                                    TypingIndicator()
                                }
                            }
                        }
                    }

                    // Bouton rond "retour en bas" : n'apparait que lorsque
                    // l'utilisateur a remonte dans l'historique, centre
                    // juste au-dessus de la pilule de saisie. Un clic fait
                    // defiler en douceur jusqu'au tout dernier message.
                    androidx.compose.animation.AnimatedVisibility(
                        visible = !isAtBottom,
                        enter = fadeIn(tween(160)) + slideInVertically(tween(160)) { it / 2 },
                        exit = fadeOut(tween(140)),
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 10.dp)
                    ) {
                        FloatingActionButton(
                            onClick = { scrollToBottom() },
                            modifier = Modifier.size(42.dp),
                            shape = CircleShape,
                            containerColor = Color.White,
                            contentColor = NovaPurple,
                            elevation = androidx.compose.material3.FloatingActionButtonDefaults.elevation(defaultElevation = 4.dp)
                        ) {
                            Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Retour en bas", modifier = Modifier.size(22.dp))
                        }
                    }
                }
            }

            InputBar(
                imageUris = pendingImageUris,
                onImageUrisChange = { pendingImageUris = it },
                onSend = { text, uris -> viewModel.sendMessage(text, uris) },
                onImagePreview = { uri -> previewTarget = ImagePreviewTarget(uri = uri) },
                onError = { msg ->
                    // On rajoute systematiquement quel moteur de
                    // reconnaissance a ete resolu (voir NovaSpeech.kt) :
                    // c'est l'info qui manquait pour savoir en un coup d'oeil
                    // si le probleme vient d'une vraie coupure reseau/service
                    // ou si Nova s'est encore liee a son propre faux moteur.
                    micErrorMessage = "$msg\n\nMoteur utilise : ${NovaSpeech.lastEngineInfo}"
                }
            )
        }

        HistoryDrawer(
            visible = historyVisible,
            assistantName = assistantName,
            userName = userName,
            conversations = viewModel.conversations,
            onDismiss = { historyVisible = false },
            onNewChat = { viewModel.startNewConversation() },
            onOpenConversation = { viewModel.openConversation(it) },
            onTogglePin = { viewModel.togglePin(it) },
            onRename = { id, title -> viewModel.renameConversation(id, title) },
            onDelete = { viewModel.deleteConversation(it) },
            onOpenSettings = { viewModel.showSettings.value = true }
        )

        if (viewModel.showModelPicker.value) {
            ModelPickerSheet(
                allModels = com.lucas.nova.data.SettingsStore.AVAILABLE_MODELS,
                unlockedModelIds = viewModel.unlockedModels.map { it.id }.toSet(),
                selectedModelId = viewModel.selectedModel.value,
                onSelect = { id -> viewModel.selectModel(id) },
                onDismiss = { viewModel.showModelPicker.value = false }
            )
        }

        if (viewModel.showSettings.value) {
            SettingsSheet(
                initialKey = viewModel.apiKeyInput.value,
                initialName = viewModel.assistantName.value,
                initialPrompt = viewModel.systemPrompt.value,
                bubbleEnabled = viewModel.bubbleEnabled.value,
                isDefaultAssistant = isDefaultAssistant,
                onSave = { key, name, prompt -> viewModel.saveSettings(key, name, prompt) },
                onDismiss = { viewModel.showSettings.value = false },
                onDeleteAll = { viewModel.deleteAllConversations() },
                onToggleBubble = { enabled ->
                    viewModel.setBubbleEnabledPreference(enabled)
                    onRequestBubbleToggle(enabled)
                },
                onRequestAssistantRole = onRequestAssistantRole
            )
        }

        AnimatedVisibility(
            visible = toastMessage != null,
            enter = fadeIn(tween(180)) + slideInVertically(tween(180)) { it / 2 },
            exit = fadeOut(tween(180)),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 90.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(MenuItemSurface)
                    .border(1.dp, GlassBorder, RoundedCornerShape(50))
                    .padding(horizontal = 18.dp, vertical = 10.dp)
            ) {
                Text(toastMessage ?: "", color = TextPrimary, fontSize = 13.sp)
            }
        }

        // Erreur micro : boite de dialogue bloquante (pas un toast qui
        // disparait tout seul) tant qu'on ne l'a pas fermee, pour ne plus
        // jamais se demander "qu'est-ce qui vient de se passer avec le
        // micro ?" faute d'avoir eu le temps de lire un toast de 2 secondes.
        micErrorMessage?.let { msg ->
            AlertDialog(
                onDismissRequest = { micErrorMessage = null },
                title = { Text("Probleme avec le micro") },
                text = {
                    androidx.compose.foundation.lazy.LazyColumn(
                        modifier = Modifier.heightIn(max = 420.dp)
                    ) {
                        item { Text(msg, fontSize = 12.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace) }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { micErrorMessage = null }) {
                        Text("OK")
                    }
                }
            )
        }

        previewTarget?.let { target ->
            ImageFullPreview(
                target = target,
                onClose = { previewTarget = null },
                onDelete = {
                    if (target.messageId != null && target.path != null) {
                        viewModel.removeImageFromMessage(target.messageId, target.path)
                    } else if (target.uri != null) {
                        pendingImageUris = pendingImageUris.filterNot { it == target.uri }
                    }
                    previewTarget = null
                }
            )
        }
    }
}

/** Cible de l'aperçu plein ecran : soit une photo pas encore envoyee
 * (identifiee par son [uri] du picker), soit une photo deja envoyee dans un
 * message existant (identifiee par son [path] local + l'id du message). */
private data class ImagePreviewTarget(
    val uri: Uri? = null,
    val path: String? = null,
    val messageId: Long? = null
)

/**
 * Aperçu plein ecran d'une photo (avant ou apres envoi) : croix en haut
 * pour fermer, bouton "supprimer" en bas. La personnalisation avancee
 * (recadrage, dessin) n'est pas incluse dans cette passe — seulement la
 * consultation et la suppression, demandees explicitement.
 */
@Composable
private fun ImageFullPreview(
    target: ImagePreviewTarget,
    onClose: () -> Unit,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    val bitmapState = produceState<androidx.compose.ui.graphics.ImageBitmap?>(initialValue = null, target) {
        value = runCatching {
            when {
                target.path != null -> android.graphics.BitmapFactory.decodeFile(target.path)?.asImageBitmap()
                target.uri != null -> context.contentResolver.openInputStream(target.uri)?.use {
                    android.graphics.BitmapFactory.decodeStream(it)?.asImageBitmap()
                }
                else -> null
            }
        }.getOrNull()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xF0000000))
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onClose() },
        contentAlignment = Alignment.Center
    ) {
        bitmapState.value?.let { bmp ->
            Image(
                bitmap = bmp,
                contentDescription = "Photo",
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                contentScale = ContentScale.Fit
            )
        }

        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .statusBarsPadding()
                .padding(18.dp)
                .size(38.dp)
                .clip(CircleShape)
                .background(Color(0x40FFFFFF))
                .clickable { onClose() },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Close, contentDescription = "Fermer", tint = Color.White, modifier = Modifier.size(20.dp))
        }

        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 24.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0x40FFFFFF))
                .clickable { onDelete() }
                .padding(horizontal = 22.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Delete, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Supprimer la photo", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun AnimatedMessageItem(content: @Composable () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(350, easing = NovaEase)) + slideInVertically(tween(350, easing = NovaEase)) { it / 6 }
    ) {
        content()
    }
}

@Composable
private fun rememberCoroutineScopeCompat() = androidx.compose.runtime.rememberCoroutineScope()

/**
 * Barre du haut minimale, exactement comme le fichier de reference :
 * juste le logo et "Nova". Le hamburger est le seul ajout necessaire pour
 * pouvoir naviguer (historique, reglages) puisqu'un apercu HTML statique
 * n'a pas besoin de cette navigation mais l'appli si.
 */
@Composable
private fun TopBar(
    assistantName: String,
    isTyping: Boolean,
    onHistoryClick: () -> Unit,
    onNewChat: () -> Unit,
    onTitleClick: () -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Start
    ) {
        IconButton(onClick = onHistoryClick, modifier = Modifier.size(30.dp)) {
            Icon(Icons.Filled.Menu, contentDescription = "Historique", tint = TextSecondary, modifier = Modifier.size(22.dp))
        }
        Spacer(modifier = Modifier.width(10.dp))
        NovaSparkleLogo(size = 22.dp)
        Spacer(modifier = Modifier.width(8.dp))
        // Menu cache : le titre est cliquable (sans indication visuelle
        // appuyee, juste "clickable" discret) pour ouvrir le choix du
        // modele, comme demande.
        Text(
            assistantName,
            color = TextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            letterSpacing = (-0.5).sp,
            modifier = Modifier.clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) { onTitleClick() }
        )
    }
}

@Composable
private fun EmptyState(assistantName: String, onSuggestionClick: (String) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 28.dp, vertical = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        Spacer(modifier = Modifier.height(70.dp))
        NovaLayersLogo(size = 40.dp)
        Spacer(modifier = Modifier.height(20.dp))
        Text(
            "Sur quoi devrions-nous\nnous concentrer ?",
            color = TextPrimary,
            fontWeight = FontWeight.Normal,
            fontSize = 28.sp,
            lineHeight = 34.sp,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )

        Spacer(modifier = Modifier.weight(1f))

        val scrollState = rememberScrollState()
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scrollState),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            suggestions.forEach { suggestion ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(18.dp))
                        .background(MenuItemSurface)
                        .border(1.dp, GlassBorder, RoundedCornerShape(18.dp))
                        .clickable { onSuggestionClick(suggestion) }
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Text(suggestion, color = TextSecondary, fontSize = 13.sp)
                }
            }
        }
        Spacer(modifier = Modifier.height(12.dp))
    }
}

/**
 * Pilule de saisie fusionnee : tout blanc, effet liquid glass minimaliste.
 * Le "+" (photo), le champ de texte, le micro (agrandi) et le bouton
 * d'envoi vivent maintenant TOUS dans la meme grande pilule, plutot que
 * d'avoir un rond d'envoi separe a cote. Le bouton d'envoi reste gris/
 * discret tant qu'il n'y a rien a envoyer, puis prend le dégradé
 * violet -> rose de l'app des qu'il y a du texte ou une photo.
 */
@Composable
private fun InputBar(
    imageUris: List<Uri>,
    onImageUrisChange: (List<Uri>) -> Unit,
    onSend: (String, List<Uri>) -> Unit,
    onImagePreview: (Uri) -> Unit,
    onError: (String) -> Unit
) {
    var text by remember { mutableStateOf("") }
    val hasContent = text.isNotBlank() || imageUris.isNotEmpty()
    val context = LocalContext.current
    // Corrige l'erreur de compilation "Unresolved reference: scope" :
    // necessaire pour relancer la dictee en arriere-plan (delai + retry)
    // depuis le RecognitionListener plus bas, sans bloquer le thread principal.
    val scope = rememberCoroutineScopeCompat()

    val pickImages = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 6)
    ) { uris -> if (uris.isNotEmpty()) onImageUrisChange((imageUris + uris).takeLast(6)) }

    // --- Dictee vocale directement dans la barre de saisie -------------
    // Avant, le micro du chat n'etait qu'une maquette (juste un toast) :
    // maintenant il ecoute vraiment, avec les memes reglages de tolerance
    // au silence que la bulle vocale, pour eviter le "je n'ai rien entendu"
    // premature.
    var isDictating by remember { mutableStateOf(false) }
    var micAmplitude by remember { mutableStateOf(0f) }
    val recognizerRef = remember { mutableStateOf<SpeechRecognizer?>(null) }
    // Un seul reessai automatique et silencieux par tentative de dictee :
    // au-dela, on affiche vraiment l'erreur plutot que de boucler
    // indefiniment sur un micro qui ne fonctionne pas du tout.
    var micAutoRetried by remember { mutableStateOf(false) }
    // Anti-rebond : meme motif deja documente et corrige cote bulle
    // assistant (BubbleService.kt) pour un double-declenchement du geste
    // sur MIUI/HyperOS. Ici, le journal de diagnostic a montre un
    // onError code=5 (ERROR_CLIENT) ~760ms apres onReadyForSpeech, sans
    // aucun onBeginningOfSpeech entre les deux -- signe typique d'un second
    // appel qui vient annuler le recognizer en plein demarrage. Le bouton
    // "+" (photo) disparaissant instantanement des le passage en dictee
    // decale toute la barre vers la gauche au meme instant, ce qui peut
    // faire atterrir un appui encore en cours sur le nouveau bouton
    // "stop" qui glisse a la meme position.
    var lastMicTapAtMs by remember { mutableStateOf(0L) }

    // --- Diagnostic detaille -------------------------------------------
    // BUG TROUVE : contrairement a BubbleService.kt (qui a un chien de
    // garde de 12s), ce micro-ci n'avait AUCUNE limite de temps. Si le
    // moteur de reconnaissance ne rappelle JAMAIS (ni onResults, ni
    // onError -- un vrai blocage silencieux, pas juste une erreur), l'appli
    // restait figee en "ecoute" pour toujours, sans jamais rien afficher.
    // C'est exactement ce qui correspond a "plus aucun message d'erreur".
    //
    // On ajoute donc : (1) un chien de garde qui force un arret propre au
    // bout de 12s si rien n'est arrive, et (2) un journal horodate de
    // CHAQUE etape du cycle de vie du recognizer, pour que le message
    // affiche dise precisement OU ca a coince (le moteur n'a jamais donne
    // signe de vie ? il a dit "pret" mais jamais detecte de debut de
    // parole ? il a bien entendu parler mais jamais renvoye de resultat ?)
    // plutot qu'un code d'erreur generique.
    var micStartedAtMs by remember { mutableStateOf(0L) }
    val micDiagLog = remember { mutableListOf<String>() }
    var micWatchdogJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }

    fun diagLog(step: String) {
        val elapsed = if (micStartedAtMs == 0L) 0L else System.currentTimeMillis() - micStartedAtMs
        micDiagLog.add("+${elapsed}ms $step")
    }

    DisposableEffect(Unit) {
        onDispose {
            micWatchdogJob?.cancel()
            recognizerRef.value?.destroy()
        }
    }

    fun stopDictation() {
        micWatchdogJob?.cancel()
        recognizerRef.value?.stopListening()
    }

    fun startDictation(isRetry: Boolean = false) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("La reconnaissance vocale n'est pas disponible sur ce telephone.")
            return
        }
        if (!isRetry) {
            micAutoRetried = false
            micDiagLog.clear()
        }
        micStartedAtMs = System.currentTimeMillis()
        diagLog("startDictation() appele (isRetry=$isRetry)")
        recognizerRef.value?.destroy()
        val recognizer = NovaSpeech.createRecognizer(context)
        diagLog("NovaSpeech.createRecognizer() -> ${if (recognizer != null) "OK" else "NULL"}, moteur=${NovaSpeech.lastEngineInfo}")
        if (recognizer == null) {
            isDictating = false
            micAmplitude = 0f
            onError(
                "La reconnaissance vocale n'est pas disponible sur ce telephone.\n\n" +
                    "Moteur utilise : ${NovaSpeech.lastEngineInfo}\n\nJournal :\n${micDiagLog.joinToString("\n")}"
            )
            return
        }
        isDictating = true
        micAmplitude = 0f
        recognizerRef.value = recognizer

        // Chien de garde : si rien (ni onResults, ni onError) n'est arrive
        // au bout de 12s, on force un arret propre avec le journal complet
        // plutot que de laisser l'UI figee en "ecoute" indefiniment.
        micWatchdogJob?.cancel()
        micWatchdogJob = scope.launch {
            kotlinx.coroutines.delay(12_000)
            if (isDictating) {
                diagLog("CHIEN DE GARDE : 12s ecoulees sans onResults ni onError -> blocage silencieux confirme")
                // Toast natif redondant avec la boite de dialogue : si pour
                // une raison quelconque notre AlertDialog Compose personnalise
                // ne s'affiche pas correctement, ce toast, lui, ne peut
                // presque pas echouer a apparaitre.
                android.widget.Toast.makeText(
                    context,
                    "Micro bloque 12s sans reponse (moteur : ${NovaSpeech.lastEngineInfo})",
                    android.widget.Toast.LENGTH_LONG
                ).show()
                try { recognizerRef.value?.cancel() } catch (e: Exception) { diagLog("cancel() a leve : ${e.message}") }
                try { recognizerRef.value?.destroy() } catch (e: Exception) { diagLog("destroy() a leve : ${e.message}") }
                recognizerRef.value = null
                isDictating = false
                micAmplitude = 0f
                onError(
                    "Le micro s'est bloque sans jamais repondre (aucune erreur, aucun resultat, meme apres 12s).\n\n" +
                        "Moteur utilise : ${NovaSpeech.lastEngineInfo}\n\nJournal :\n${micDiagLog.joinToString("\n")}"
                )
            }
        }

        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { diagLog("onReadyForSpeech") }
            override fun onBeginningOfSpeech() { diagLog("onBeginningOfSpeech (le moteur a detecte le debut d'une parole)") }
            override fun onRmsChanged(rmsdB: Float) {
                micAmplitude = (rmsdB / 10f).coerceIn(0f, 1f)
            }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                diagLog("onEndOfSpeech (le moteur considere que la parole est terminee, en attente du resultat)")
                micAmplitude = 0f
            }
            override fun onError(error: Int) {

                diagLog("onError code=$error")
                // Detruit systematiquement l'instance en erreur plutot que
                // de la laisser trainer : certaines erreurs (notamment le
                // code 11 = ERROR_SERVER_DISCONNECTED, tres frequent quand
                // le service de reconnaissance du telephone se coupe en
                // plein milieu, y compris sur HyperOS/MIUI) laissent le
                // SpeechRecognizer dans un etat interne casse. Le
                // reutiliser tel quel au prochain tap sur le micro faisait
                // que les barres d'animation se figeaient (le recognizer ne
                // renvoyait plus aucun callback). En le detruisant ici et en
                // videant la reference, la relance repart d'une instance
                // fraiche.
                try { recognizerRef.value?.destroy() } catch (e: Exception) { /* deja detruit */ }
                recognizerRef.value = null

                // Erreurs transitoires : on relance automatiquement le
                // micro une seule fois, silencieusement, SANS repasser
                // isDictating a false entre-temps — c'est justement ce
                // retour a false suivi d'un blocage qui donnait
                // l'impression que l'UI se figeait sur certains
                // telephones (notamment les Redmi/Xiaomi en HyperOS).
                val transient = error == SpeechRecognizer.ERROR_NETWORK ||
                    error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ||
                    error == SpeechRecognizer.ERROR_SERVER ||
                    error == SpeechRecognizer.ERROR_SERVER_DISCONNECTED ||
                    error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ||
                    error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ||
                    error == SpeechRecognizer.ERROR_NO_MATCH ||
                    // ERROR_CLIENT (5) : filet de securite en plus de
                    // l'anti-rebond sur le tap (voir lastMicTapAtMs) --
                    // si un double-appel survient quand meme pour une
                    // autre raison, on retente une fois plutot que
                    // d'echouer directement.
                    error == SpeechRecognizer.ERROR_CLIENT

                if (transient && !micAutoRetried) {
                    micAutoRetried = true
                    micAmplitude = 0f
                    diagLog("erreur transitoire -> reessai automatique dans 350ms")
                    // Petit delai avant de recreer le SpeechRecognizer : le
                    // detruire puis le recreer dans la meme frame (sans
                    // laisser le service de reconnaissance liberer ses
                    // ressources) provoquait parfois un echec immediat sur
                    // certains telephones (meme constat que dans
                    // BubbleService.kt).
                    micWatchdogJob?.cancel()
                    scope.launch {
                        kotlinx.coroutines.delay(350)
                        if (isDictating) startDictation(isRetry = true)
                    }
                    return
                }

                micWatchdogJob?.cancel()
                isDictating = false
                micAmplitude = 0f
                // Code technique + moteur + journal complet inclus pour un
                // diagnostic precis, sans avoir besoin de brancher le
                // telephone pour lire les logs.
                val engineAndLog = "\n\nMoteur utilise : ${NovaSpeech.lastEngineInfo}\n\nJournal :\n${micDiagLog.joinToString("\n")}"
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                        onError("Je n'ai pas bien entendu, reessaie. (code $error)$engineAndLog")
                    SpeechRecognizer.ERROR_SERVER_DISCONNECTED ->
                        onError("Le service vocal s'est deconnecte, reessaie. (code $error)$engineAndLog")
                    else ->
                        onError("Le micro n'a pas pu etre utilise, reessaie. (code $error)$engineAndLog")
                }
            }
            override fun onResults(results: Bundle?) {
                diagLog("onResults recu")
                micWatchdogJob?.cancel()
                isDictating = false
                micAmplitude = 0f
                // Meme logique qu'en erreur : on detruit l'instance une
                // fois le resultat recu plutot que de la garder ouverte en
                // arriere-plan, pour repartir propre au prochain tap.
                try { recognizerRef.value?.destroy() } catch (e: Exception) { /* deja detruit */ }
                recognizerRef.value = null
                val spoken = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                if (spoken.isNotBlank()) {
                    text = if (text.isBlank()) spoken else "$text $spoken"
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            // 5000ms (au lieu de 1500ms) : certaines surcouches constructeur
            // (HyperOS/MIUI sur les Redmi/Xiaomi notamment) coupent le
            // SpeechRecognizer bien plus tot que la valeur demandee si elle
            // est trop courte, ce qui donnait l'impression que le micro
            // "plantait" ou se figeait au milieu d'une phrase.
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 5000)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 5000)
            // Voir le commentaire equivalent dans BubbleService.kt : cet
            // extra force une duree MINIMALE d'enregistrement obligatoire
            // (pas une tolerance de silence), 15s etait beaucoup trop eleve
            // et cassait la transcription.
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 2_000)
        }
        diagLog("appel de recognizer.startListening()")
        try {
            recognizer.startListening(recognizerIntent)
        } catch (e: Exception) {
            diagLog("startListening() a leve une exception : ${e.javaClass.simpleName} : ${e.message}")
            micWatchdogJob?.cancel()
            isDictating = false
            onError(
                "Le micro n'a pas pu demarrer, reessaie.\n\n" +
                    "Moteur utilise : ${NovaSpeech.lastEngineInfo}\n\nJournal :\n${micDiagLog.joinToString("\n")}"
            )
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startDictation()
        else onError("Autorise le micro dans les reglages du telephone pour dicter un message.")
    }

    fun onMicClick() {
        // DIAGNOSTIC RADICAL : un vrai Toast Android natif (pas notre boite
        // de dialogue Compose, qui depend de la recomposition et pourrait en
        // theorie echouer silencieusement) affiche EN PREMIER, avant tout le
        // reste. But : trancher une bonne fois pour toutes entre deux
        // hypotheses tres differentes si le prochain test ne montre encore
        // aucun message : (1) le tap n'est meme pas detecte par le code
        // (bouton bloque, ancien APK encore installe...) -> ce toast
        // n'apparaitra JAMAIS ; ou (2) le tap est bien detecte mais quelque
        // chose plante ou se bloque plus loin -> ce toast apparaitra mais
        // rien d'autre ne suivra.
        android.widget.Toast.makeText(context, "Micro : appui detecte", android.widget.Toast.LENGTH_SHORT).show()
        val now = System.currentTimeMillis()
        if (now - lastMicTapAtMs < 700) {
            // Anti-rebond : on ignore cet appui, trop proche du precedent
            // pour etre un vrai second geste intentionnel (voir le
            // commentaire au niveau de la declaration de lastMicTapAtMs).
            return
        }
        lastMicTapAtMs = now
        try {
            if (isDictating) {
                stopDictation()
                return
            }
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED
            ) {
                startDictation()
            } else {
                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        } catch (e: Exception) {
            // Si quoi que ce soit plante de maniere SYNCHRONE ici (avant
            // meme d'atteindre le recognizer), on le voit enfin au lieu que
            // ca disparaisse en silence sans jamais atteindre onError() ni
            // le chien de garde.
            android.widget.Toast.makeText(
                context,
                "Erreur immediate au clic micro : ${e.javaClass.simpleName} : ${e.message}",
                android.widget.Toast.LENGTH_LONG
            ).show()
        }
    }

    fun doSend() {
        if (isDictating) stopDictation()
        if (text.isNotBlank() || imageUris.isNotEmpty()) {
            onSend(text, imageUris)
            text = ""
            onImageUrisChange(emptyList())
        }
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        // Apercu des photos choisies : rangee de vignettes qui defile,
        // collee juste au-dessus de la pilule, chacune avec sa croix pour
        // l'enlever et un clic pour l'agrandir en plein ecran.
        AnimatedVisibility(
            visible = imageUris.isNotEmpty(),
            enter = fadeIn(tween(180)) + slideInVertically(tween(180)) { it / 2 },
            exit = fadeOut(tween(140))
        ) {
            LazyRow(
                modifier = Modifier.padding(start = 24.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(imageUris, key = { it.toString() }) { uri ->
                    ImagePreviewThumbnail(
                        uri = uri,
                        onClick = { onImagePreview(uri) },
                        onRemove = { onImageUrisChange(imageUris.filterNot { it == uri }) }
                    )
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            // Pilule blanc plat, uniforme, coins bien arrondis type "liquid
            // glass" doux : plus de degrade "verre" ni d'ombre marquee
            // (ancien rendu multicolore), juste un blanc pur avec un liseré
            // fin et discret pour un look moderne et minimaliste.
            Row(
                modifier = Modifier
                    .weight(1f)
                    .shadow(4.dp, RoundedCornerShape(36.dp), ambientColor = Color(0x1A000000), spotColor = Color(0x1A000000))
                    .clip(RoundedCornerShape(36.dp))
                    .background(Color.White)
                    .border(1.dp, Color(0xFFECECF1), RoundedCornerShape(36.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Le bouton reste TOUJOURS present dans la mise en page
                // (juste invisible et desactive pendant la dictee) plutot
                // que d'etre retire de la composition : le retirer
                // completement faisait glisser instantanement toute la
                // barre vers la gauche des le passage en dictee, ce qui
                // pouvait faire atterrir un appui encore en cours sur le
                // bouton "stop" qui glissait a la meme position -- cause
                // probable du ERROR_CLIENT observe juste apres le demarrage
                // du micro (voir le journal de diagnostic).
                IconButton(
                    onClick = { pickImages.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    enabled = !isDictating,
                    modifier = Modifier.size(40.dp).alpha(if (isDictating) 0f else 1f)
                ) {
                    Icon(Icons.Filled.Add, contentDescription = "Ajouter une ou plusieurs photos", tint = NovaPurple.copy(alpha = 0.75f), modifier = Modifier.size(23.dp))
                }

                if (isDictating) {
                    // Pendant la dictee : le champ de texte laisse place a
                    // des traits (barres) gras et minimalistes qui bougent
                    // au rythme de la voix, comme demande.
                    Box(modifier = Modifier.weight(1f).padding(horizontal = 6.dp), contentAlignment = Alignment.Center) {
                        DictationWaveform(amplitude = micAmplitude)
                    }
                } else {
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it },
                        modifier = Modifier
                            .weight(1f)
                            .padding(vertical = 2.dp),
                        placeholder = { Text("Écrire un message...", color = TextSecondary, fontSize = 16.sp) },
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 16.sp),
                        singleLine = false,
                        maxLines = 5,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = androidx.compose.foundation.text.KeyboardActions(
                            onSend = { doSend() }
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            cursorColor = NovaPurple
                        )
                    )
                }

                // Micro cache quand une photo est deja jointe : envoyer une
                // photo ET parler en meme temps n'a pas de sens, ca ne fait
                // que surcharger la pilule de saisie pour rien. Pendant la
                // dictee, il devient un joli bouton carre pour l'arreter.
                if (imageUris.isEmpty()) {
                    if (isDictating) {
                        Box(
                            modifier = Modifier
                                .padding(horizontal = 2.dp)
                                .size(38.dp)
                                .clip(RoundedCornerShape(11.dp))
                                .background(Brush.linearGradient(listOf(NovaPurple, NovaPink)))
                                .clickable { onMicClick() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Stop, contentDescription = "Arreter la dictee", tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                    } else {
                        IconButton(onClick = { onMicClick() }, modifier = Modifier.size(46.dp)) {
                            Icon(Icons.Filled.Mic, contentDescription = "Micro", tint = NovaPurple.copy(alpha = 0.75f), modifier = Modifier.size(26.dp))
                        }
                    }
                }

                Spacer(modifier = Modifier.width(2.dp))

                // Bouton d'envoi integre dans la meme pilule : gris/plat tant
                // qu'il n'y a rien, degrade violet-rose des qu'il y a du texte
                // ou une photo a envoyer. Un leger "pop" au relachement rend
                // l'appui plus vivant, plutot qu'un changement d'etat brut.
                val sendInteraction = remember { MutableInteractionSource() }
                val sendPressed by sendInteraction.collectIsPressedAsState()
                val sendScale by animateFloatAsState(
                    targetValue = if (sendPressed) 0.88f else 1f,
                    animationSpec = spring(dampingRatio = 0.5f, stiffness = 600f),
                    label = "sendScale"
                )
                Box(
                    modifier = Modifier
                        .padding(vertical = 5.dp, horizontal = 2.dp)
                        .size(42.dp)
                        .graphicsLayer { scaleX = sendScale; scaleY = sendScale }
                        .clip(CircleShape)
                        .background(
                            if (hasContent) Brush.linearGradient(listOf(NovaPurple, NovaPink))
                            else Brush.linearGradient(listOf(Color(0xFFE4E4E9), Color(0xFFE4E4E9)))
                        )
                        .clickable(
                            enabled = hasContent,
                            indication = null,
                            interactionSource = sendInteraction
                        ) { doSend() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Envoyer",
                        tint = if (hasContent) Color.White else Color(0xFFB4B4BC),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

/** Barres de dictee : gras, minimaliste, suit le volume de la voix
 * (micAmplitude, 0f..1f venant du SpeechRecognizer) avec une legere
 * respiration douce en silence pour ne pas paraitre figee. */
@Composable
private fun DictationWaveform(amplitude: Float) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        val weights = listOf(0.5f, 0.8f, 1f, 0.7f, 0.9f, 0.55f)
        weights.forEach { w -> DictationBar(weight = w, amplitude = amplitude) }
    }
}

@Composable
private fun DictationBar(weight: Float, amplitude: Float) {
    // AVANT : cette "respiration" douce en silence utilisait la MEME
    // couleur (violet plein) que le vrai signal audio -- ce qui rendait
    // totalement impossible de distinguer visuellement "le micro capte
    // vraiment du son" de "rien n'est capte du tout, ceci est juste une
    // decoration animee". C'est exactement ce qui a fait croire, au tout
    // debut du diagnostic, que le micro "marchait" (barres qui bougent)
    // alors qu'aucune vraie donnee audio n'arrivait. Desormais : gris et
    // nettement plus discret quand c'est cette animation decorative, violet
    // vif UNIQUEMENT quand un vrai niveau audio est recu (amplitude reelle
    // >= 0.06, cf. onRmsChanged dans startDictation()).
    val isRealSignal = amplitude >= 0.06f
    val transition = rememberInfiniteTransition(label = "dictationBreath")
    val idlePulse by transition.animateFloat(
        initialValue = 0.10f,
        targetValue = 0.18f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "dictationIdle"
    )
    val fraction = if (isRealSignal) (amplitude * weight).coerceIn(0f, 1f) else idlePulse
    val height: Dp by animateDpAsState(
        targetValue = 6.dp + (26.dp) * fraction,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 700f),
        label = "dictationBarHeight"
    )
    val barColor: Color by animateColorAsState(
        targetValue = if (isRealSignal) NovaPurple else Color(0xFFC7C7CE),
        label = "dictationBarColor"
    )
    Box(
        modifier = Modifier
            .width(5.dp)
            .height(height)
            .clip(RoundedCornerShape(4.dp))
            .background(barColor)
    )
}

/** Petite vignette carree pour l'aperçu d'une photo choisie, avec un bouton
 * pour l'enlever avant l'envoi et un clic pour l'agrandir en plein ecran. */
@Composable
private fun ImagePreviewThumbnail(uri: Uri, onClick: () -> Unit, onRemove: () -> Unit) {
    val context = LocalContext.current
    val bitmapState = produceState<androidx.compose.ui.graphics.ImageBitmap?>(initialValue = null, uri) {
        value = runCatching {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                android.graphics.BitmapFactory.decodeStream(stream)?.asImageBitmap()
            }
        }.getOrNull()
    }

    Box(modifier = Modifier.size(56.dp)) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .shadow(2.dp, RoundedCornerShape(14.dp))
                .clip(RoundedCornerShape(14.dp))
                .background(MenuItemSurface)
                .border(1.dp, GlassBorder, RoundedCornerShape(14.dp))
                .clickable { onClick() }
        ) {
            bitmapState.value?.let { bmp ->
                Image(
                    bitmap = bmp,
                    contentDescription = "Photo jointe",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
        }
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(2.dp)
                .size(18.dp)
                .clip(CircleShape)
                .background(Color(0xE6000000))
                .clickable { onRemove() },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Close, contentDescription = "Retirer la photo", tint = Color.White, modifier = Modifier.size(11.dp))
        }
    }
}
