package com.lucas.nova.assistant

import android.content.Intent
import android.speech.RecognitionService

/**
 * Certains telephones (notamment MIUI) exigent qu'un "recognitionService"
 * valide soit declare dans voice_interaction_service.xml pour qu'Android
 * considere l'app comme eligible au role Assistant par defaut, meme si Nova
 * n'utilise pas ce chemin (la bulle utilise son propre SpeechRecognizer,
 * voir BubbleService). Ce service n'est donc jamais reellement sollicite,
 * il existe uniquement pour satisfaire cette condition d'eligibilite.
 */
class NovaRecognitionService : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        listener?.error(android.speech.SpeechRecognizer.ERROR_CLIENT)
    }

    override fun onCancel(listener: Callback?) {}

    override fun onStopListening(listener: Callback?) {}
}
