package com.lucas.nova.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ConversationMeta(
    val id: String,
    val title: String,
    val updatedAt: Long,
    val pinned: Boolean = false,
    val customTitle: Boolean = false
)

/**
 * Stocke plusieurs conversations en local (JSON dans SharedPreferences).
 * Gere aussi l'epinglage, le renommage et la suppression, comme dans Gemini.
 */
class ConversationStore(context: Context) {
    private val prefs = context.getSharedPreferences("nova_conversations", Context.MODE_PRIVATE)
    private val indexKey = "conversation_index"

    private fun readIndex(): MutableList<ConversationMeta> {
        val raw = prefs.getString(indexKey, null) ?: return mutableListOf()
        val array = JSONArray(raw)
        val list = mutableListOf<ConversationMeta>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            list.add(
                ConversationMeta(
                    id = obj.getString("id"),
                    title = obj.getString("title"),
                    updatedAt = obj.getLong("updatedAt"),
                    pinned = obj.optBoolean("pinned", false),
                    customTitle = obj.optBoolean("customTitle", false)
                )
            )
        }
        return list
    }

    private fun writeIndex(list: List<ConversationMeta>) {
        val array = JSONArray()
        for (meta in list) {
            val obj = JSONObject()
            obj.put("id", meta.id)
            obj.put("title", meta.title)
            obj.put("updatedAt", meta.updatedAt)
            obj.put("pinned", meta.pinned)
            obj.put("customTitle", meta.customTitle)
            array.put(obj)
        }
        prefs.edit().putString(indexKey, array.toString()).apply()
    }

    fun listConversations(): List<ConversationMeta> {
        return readIndex().sortedWith(
            compareByDescending<ConversationMeta> { it.pinned }.thenByDescending { it.updatedAt }
        )
    }

    fun loadMessages(conversationId: String): List<ChatMessage> {
        val raw = prefs.getString("conv_$conversationId", null) ?: return emptyList()
        val array = JSONArray(raw)
        val list = mutableListOf<ChatMessage>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            list.add(
                ChatMessage(
                    text = obj.getString("text"),
                    isUser = obj.getBoolean("isUser"),
                    isError = obj.optBoolean("isError", false),
                    imagePaths = obj.optJSONArray("imagePaths")?.let { arr ->
                        (0 until arr.length()).map { arr.getString(it) }
                    } ?: emptyList()
                )
            )
        }
        return list
    }

    fun saveConversation(conversationId: String, messages: List<ChatMessage>) {
        if (messages.isEmpty()) return

        val array = JSONArray()
        for (msg in messages) {
            val obj = JSONObject()
            obj.put("text", msg.text)
            obj.put("isUser", msg.isUser)
            obj.put("isError", msg.isError)
            if (msg.imagePaths.isNotEmpty()) obj.put("imagePaths", JSONArray(msg.imagePaths))
            array.put(obj)
        }
        prefs.edit().putString("conv_$conversationId", array.toString()).apply()

        val index = readIndex()
        val existing = index.find { it.id == conversationId }
        val autoTitle = messages.firstOrNull { it.isUser }?.text?.take(48) ?: "Nouvelle discussion"

        val updated = ConversationMeta(
            id = conversationId,
            title = if (existing?.customTitle == true) existing.title else autoTitle,
            updatedAt = System.currentTimeMillis(),
            pinned = existing?.pinned ?: false,
            customTitle = existing?.customTitle ?: false
        )

        index.removeAll { it.id == conversationId }
        index.add(updated)
        writeIndex(index)
    }

    fun togglePin(conversationId: String) {
        val index = readIndex()
        val updated = index.map {
            if (it.id == conversationId) it.copy(pinned = !it.pinned) else it
        }
        writeIndex(updated)
    }

    fun renameConversation(conversationId: String, newTitle: String) {
        if (newTitle.isBlank()) return
        val index = readIndex()
        val updated = index.map {
            if (it.id == conversationId) it.copy(title = newTitle.trim(), customTitle = true) else it
        }
        writeIndex(updated)
    }

    fun deleteConversation(conversationId: String) {
        val index = readIndex()
        index.removeAll { it.id == conversationId }
        writeIndex(index)
        prefs.edit().remove("conv_$conversationId").apply()
    }

    fun deleteAll() {
        val index = readIndex()
        val editor = prefs.edit()
        for (meta in index) {
            editor.remove("conv_${meta.id}")
        }
        editor.remove(indexKey)
        editor.apply()
    }

    fun newConversationId(): String = System.currentTimeMillis().toString()
}
