package com.lucas.nova.bubble

/**
 * Les differents etats visuels de la bulle assistant, repris du design
 * peaufine par Lucas : repliee -> ecoute -> reflexion -> reponse.
 */
enum class BubblePhase {
    IDLE,
    LISTENING,
    THINKING,
    REPLY
}
