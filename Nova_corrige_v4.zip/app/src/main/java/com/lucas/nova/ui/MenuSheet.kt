package com.lucas.nova.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lucas.nova.ui.theme.GlassBorder
import com.lucas.nova.ui.theme.MenuItemSurface
import com.lucas.nova.ui.theme.MenuSurface
import com.lucas.nova.ui.theme.NovaBlue
import com.lucas.nova.ui.theme.NovaPink
import com.lucas.nova.ui.theme.NovaPurple
import com.lucas.nova.ui.theme.TextPrimary
import com.lucas.nova.ui.theme.TextSecondary
import com.lucas.nova.ui.theme.TextTertiary

data class NovaMenuAction(
    val label: String,
    val icon: ImageVector,
    val available: Boolean,
    val onClick: () -> Unit
)

@Composable
fun MenuSheet(
    visible: Boolean,
    onDismiss: () -> Unit,
    onOpenSettings: () -> Unit,
    onNewChat: () -> Unit,
    onUnavailableAction: (String) -> Unit
) {
    val actions = listOf(
        NovaMenuAction("Nouveau chat", Icons.AutoMirrored.Filled.Chat, true, onNewChat),
        NovaMenuAction("Envoyer un SMS", Icons.AutoMirrored.Filled.Send, false) { onUnavailableAction("Envoyer un SMS") },
        NovaMenuAction("Passer un appel", Icons.Filled.Call, false) { onUnavailableAction("Passer un appel") },
        NovaMenuAction("Agenda", Icons.Filled.Event, false) { onUnavailableAction("Agenda") },
        NovaMenuAction("Recherche web", Icons.Filled.Search, false) { onUnavailableAction("Recherche web") },
        NovaMenuAction("Mode silencieux", Icons.Filled.NotificationsOff, false) { onUnavailableAction("Mode silencieux") },
        NovaMenuAction("Volume", Icons.Filled.VolumeUp, false) { onUnavailableAction("Volume") },
        NovaMenuAction("Réglages", Icons.Filled.Settings, true, onOpenSettings)
    )

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(200)),
        exit = fadeOut(tween(200))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xB3050509))
                .clickable(
                    indication = null,
                    interactionSource = remember_ns(),
                    onClick = onDismiss
                ),
            contentAlignment = Alignment.BottomCenter
        ) {
            AnimatedVisibility(
                visible = visible,
                enter = slideInVertically(tween(280)) { it } + fadeIn(tween(280)),
                exit = slideOutVertically(tween(220)) { it } + fadeOut(tween(180))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(14.dp, RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                        .clickable(indication = null, interactionSource = remember_ns()) { }
                        .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                        .background(MenuSurface)
                        .border(
                            1.dp, GlassBorder,
                            RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
                        )
                        .padding(bottom = 28.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .padding(top = 12.dp)
                            .align(Alignment.CenterHorizontally)
                            .width(38.dp)
                            .height(4.dp)
                            .clip(RoundedCornerShape(50))
                            .background(TextTertiary)
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 22.dp, vertical = 18.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Menu", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(MenuItemSurface)
                                .clickable { onDismiss() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Close, contentDescription = "Fermer", tint = TextSecondary, modifier = Modifier.size(16.dp))
                        }
                    }

                    LazyVerticalGrid(
                        columns = GridCells.Fixed(4),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(actions) { action ->
                            MenuIconItem(action)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MenuIconItem(action: NovaMenuAction) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .clickable { action.onClick() }
            .padding(vertical = 12.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(
                    if (action.available)
                        Brush.linearGradient(listOf(NovaPurple.copy(alpha = 0.9f), NovaBlue.copy(alpha = 0.9f)))
                    else
                        Brush.linearGradient(listOf(MenuItemSurface, MenuItemSurface))
                )
                .border(1.dp, GlassBorder, RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                action.icon,
                contentDescription = action.label,
                tint = if (action.available) Color.White else TextTertiary,
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = action.label,
            color = if (action.available) TextSecondary else TextTertiary,
            fontSize = 11.sp,
            textAlign = TextAlign.Center,
            maxLines = 2
        )
        if (!action.available) {
            Text(
                text = "bientôt",
                color = NovaPink,
                fontSize = 9.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun remember_ns(): MutableInteractionSource {
    return androidx.compose.runtime.remember { MutableInteractionSource() }
}
