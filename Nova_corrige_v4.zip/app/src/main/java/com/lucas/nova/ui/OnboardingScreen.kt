package com.lucas.nova.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lucas.nova.ui.theme.NovaBlue
import com.lucas.nova.ui.theme.NovaPink
import com.lucas.nova.ui.theme.NovaPurple
import com.lucas.nova.ui.theme.TextPrimary
import com.lucas.nova.ui.theme.TextSecondary
import com.lucas.nova.ui.theme.TextTertiary

private enum class OnboardingStep { NAME, API_KEY }

/**
 * Ecran de bienvenue montre une seule fois (tant que
 * SettingsStore.isOnboardingComplete() est faux) : demande le prenom de
 * l'utilisateur, puis la cle API Gemini (avec possibilite de passer cette
 * etape), avant de laisser MainActivity faire l'animation de transition
 * vers l'ecran de conversation.
 */
@Composable
fun OnboardingScreen(onFinish: (userName: String, apiKey: String) -> Unit) {
    var step by remember { mutableStateOf(OnboardingStep.NAME) }
    var name by remember { mutableStateOf("") }
    var apiKey by remember { mutableStateOf("") }

    NovaBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            NovaLayersLogo(size = 48.dp)
            Spacer(height = 28.dp)

            AnimatedContent(
                targetState = step,
                transitionSpec = {
                    (slideInHorizontally(tween(320)) { it / 4 } + fadeIn(tween(320))) togetherWith
                        (slideOutHorizontally(tween(220)) { -it / 4 } + fadeOut(tween(180)))
                },
                label = "onboarding-step"
            ) { current ->
                when (current) {
                    OnboardingStep.NAME -> NameStep(
                        name = name,
                        onNameChange = { name = it },
                        onContinue = { step = OnboardingStep.API_KEY }
                    )
                    OnboardingStep.API_KEY -> ApiKeyStep(
                        apiKey = apiKey,
                        onApiKeyChange = { apiKey = it },
                        onFinish = { onFinish(name.trim().ifBlank { "Toi" }, apiKey.trim()) },
                        onSkip = { onFinish(name.trim().ifBlank { "Toi" }, "") }
                    )
                }
            }
        }
    }
}

@Composable
private fun NameStep(name: String, onNameChange: (String) -> Unit, onContinue: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            "Bonjour !",
            color = TextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 26.sp
        )
        Spacer(height = 8.dp)
        Text(
            "Comment veux-tu que je t'appelle ?",
            color = TextSecondary,
            fontSize = 15.sp
        )
        Spacer(height = 26.dp)

        OutlinedTextField(
            value = name,
            onValueChange = onNameChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Ton prénom", color = TextTertiary) },
            singleLine = true,
            shape = RoundedCornerShape(18.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
            colors = onboardingFieldColors()
        )
        Spacer(height = 22.dp)

        PrimaryButton(
            label = "Continuer",
            enabled = name.isNotBlank(),
            onClick = onContinue
        )
    }
}

@Composable
private fun ApiKeyStep(
    apiKey: String,
    onApiKeyChange: (String) -> Unit,
    onFinish: () -> Unit,
    onSkip: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            "Ta clé API Gemini",
            color = TextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 26.sp
        )
        Spacer(height = 8.dp)
        Text(
            "Nécessaire pour que je puisse te répondre. Tu peux aussi passer cette étape et l'ajouter plus tard dans les réglages.",
            color = TextSecondary,
            fontSize = 14.sp,
            lineHeight = 19.sp,
            modifier = Modifier.padding(horizontal = 8.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Spacer(height = 26.dp)

        OutlinedTextField(
            value = apiKey,
            onValueChange = onApiKeyChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Coller ta clé API", color = TextTertiary) },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            shape = RoundedCornerShape(18.dp),
            colors = onboardingFieldColors()
        )
        Spacer(height = 22.dp)

        PrimaryButton(
            label = "Enregistrer et commencer",
            enabled = apiKey.isNotBlank(),
            onClick = onFinish
        )
        Spacer(height = 14.dp)
        Text(
            "Passer cette étape",
            color = TextSecondary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .clickable { onSkip() }
                .padding(horizontal = 12.dp, vertical = 8.dp)
        )
    }
}

@Composable
private fun PrimaryButton(label: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(
                if (enabled) Brush.linearGradient(listOf(NovaPurple, NovaPink))
                else Brush.linearGradient(listOf(Color(0xFFE4E4E9), Color(0xFFE4E4E9)))
            )
            .clickable(enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = if (enabled) Color.White else Color(0xFFB4B4BC),
            fontWeight = FontWeight.SemiBold,
            fontSize = 15.sp
        )
    }
}

@Composable
private fun onboardingFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary,
    focusedBorderColor = NovaBlue,
    unfocusedBorderColor = Color(0x1F0A0A2E),
    cursorColor = NovaBlue,
    focusedContainerColor = Color(0x99FFFFFF),
    unfocusedContainerColor = Color(0x99FFFFFF)
)

@Composable
private fun Spacer(height: androidx.compose.ui.unit.Dp) {
    Box(modifier = Modifier.height(height))
}
