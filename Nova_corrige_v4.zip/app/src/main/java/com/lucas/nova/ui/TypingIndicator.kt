package com.lucas.nova.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import com.lucas.nova.ui.theme.NovaBlue

/**
 * Trois points qui indiquent que Nova reflechit, SANS bulle/fond autour
 * (juste les points, comme demande) : avant, ils etaient a tort places
 * dans une bulle de conversation complete, ce qui faisait doublon visuel
 * avec les vraies bulles de message.
 */
@Composable
fun TypingIndicator() {
    Box(modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)) {
        Row {
            repeat(3) { index ->
                Dot(delayMillis = index * 150)
                if (index != 2) Box(modifier = Modifier.width(6.dp))
            }
        }
    }
}

@Composable
private fun Dot(delayMillis: Int) {
    val transition = rememberInfiniteTransition(label = "dot")
    val scale by transition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 600, delayMillis = delayMillis),
            repeatMode = RepeatMode.Reverse
        ),
        label = "dotScale"
    )
    Box(
        modifier = Modifier
            .size(9.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(CircleShape)
            .background(NovaBlue)
    )
}
