package com.lucas.nova

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lucas.nova.bubble.BubbleService
import com.lucas.nova.data.ConversationStore
import com.lucas.nova.data.SettingsStore
import com.lucas.nova.ui.ChatScreen
import com.lucas.nova.ui.OnboardingScreen
import com.lucas.nova.ui.theme.NovaTheme

class ChatViewModelFactory(
    private val appContext: android.content.Context,
    private val settingsStore: SettingsStore,
    private val conversationStore: ConversationStore
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
        return ChatViewModel(appContext, settingsStore, conversationStore) as T
    }
}

class MainActivity : ComponentActivity() {

    private lateinit var settingsStore: SettingsStore
    private var isDefaultAssistant by mutableStateOf(false)
    private var onboardingComplete by mutableStateOf(false)

    // ===== Permission "Afficher par-dessus les autres applis" (pour la bulle) =====
    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (Settings.canDrawOverlays(this)) {
            requestMicThenStartBubble()
        } else {
            settingsStore.setBubbleEnabled(false)
        }
    }

    private val micPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            requestNotificationsThenStartBubble()
        } else {
            settingsStore.setBubbleEnabled(false)
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        // Que la permission notifications soit accordee ou non, le service peut demarrer :
        // elle ameliore juste la visibilite de la notification persistante.
        startBubbleService()
    }

    // ===== Role systeme "Assistant par defaut du telephone" =====
    private val assistantRoleLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        refreshAssistantRoleStatus()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        settingsStore = SettingsStore(applicationContext)
        val conversationStore = ConversationStore(applicationContext)
        onboardingComplete = settingsStore.isOnboardingComplete()

        setContent {
            NovaTheme {
                // Ecran de bienvenue (prenom + cle API, skippable) la toute
                // premiere fois, puis animation vers l'ecran de conversation.
                // AnimatedContent avec un fondu + leger zoom donne la sensation
                // de "passage" demandee plutot qu'un changement brut d'ecran.
                AnimatedContent(
                    targetState = onboardingComplete,
                    transitionSpec = {
                        (fadeIn(tween(420)) + scaleIn(tween(420), initialScale = 0.96f)) togetherWith
                            fadeOut(tween(220))
                    },
                    label = "onboarding-to-chat"
                ) { done ->
                    if (!done) {
                        OnboardingScreen(
                            onFinish = { userName, apiKey ->
                                settingsStore.setUserName(userName)
                                if (apiKey.isNotBlank()) settingsStore.setApiKey(apiKey)
                                settingsStore.setOnboardingComplete(true)
                                onboardingComplete = true
                            }
                        )
                    } else {
                        val viewModel: ChatViewModel = viewModel(
                            factory = ChatViewModelFactory(applicationContext, settingsStore, conversationStore)
                        )
                        ChatScreen(
                            viewModel = viewModel,
                            isDefaultAssistant = isDefaultAssistant,
                            onRequestBubbleToggle = { enabled ->
                                if (enabled) beginEnableBubbleFlow() else stopBubbleService()
                            },
                            onRequestAssistantRole = { requestAssistantRole() }
                        )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // On revient peut-etre de l'ecran systeme ou l'utilisateur a choisi
        // Nova comme assistant : on remet a jour l'etat affiche.
        refreshAssistantRoleStatus()
    }

    private fun refreshAssistantRoleStatus() {
        isDefaultAssistant = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(RoleManager::class.java)
            roleManager?.isRoleHeld(RoleManager.ROLE_ASSISTANT) ?: false
        } else {
            false
        }
    }

    /**
     * Ouvre l'ecran systeme qui permet a l'utilisateur de definir Nova comme
     * application assistante par defaut. C'est ce qui permet ensuite au geste
     * d'assistant (appui long sur le bouton power, geste de coin, etc.) de
     * lancer directement la bulle Nova en ecoute.
     */
    private fun requestAssistantRole() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_ASSISTANT)) {
                if (!roleManager.isRoleHeld(RoleManager.ROLE_ASSISTANT)) {
                    val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_ASSISTANT)
                    assistantRoleLauncher.launch(intent)
                }
                return
            }
        }
        // Repli pour Android < 10, ou si le role n'est pas propose par le
        // fabricant (certains telephones MIUI le cachent) : on ouvre l'ecran
        // systeme classique de choix de l'appli assistante.
        try {
            assistantRoleLauncher.launch(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
        } catch (e: Exception) {
            // Cet ecran n'existe pas sur ce telephone, rien de plus a faire.
        }
    }

    private fun beginEnableBubbleFlow() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
        } else {
            requestMicThenStartBubble()
        }
    }

    private fun requestMicThenStartBubble() {
        val micGranted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (micGranted) {
            requestNotificationsThenStartBubble()
        } else {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun requestNotificationsThenStartBubble() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val notifGranted = ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED

            if (notifGranted) {
                startBubbleService()
            } else {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        } else {
            startBubbleService()
        }
    }

    private fun startBubbleService() {
        val intent = Intent(this, BubbleService::class.java)
        ContextCompat.startForegroundService(this, intent)
        settingsStore.setBubbleEnabled(true)
    }

    private fun stopBubbleService() {
        stopService(Intent(this, BubbleService::class.java))
        settingsStore.setBubbleEnabled(false)
    }
}
