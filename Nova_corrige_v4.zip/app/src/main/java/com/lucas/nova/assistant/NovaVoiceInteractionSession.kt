package com.lucas.nova.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.service.voice.VoiceInteractionSession
import androidx.core.content.ContextCompat
import com.lucas.nova.bubble.BubbleService

/**
 * Session invoquee par Android quand l'utilisateur declenche le geste
 * d'assistant (appui long sur le bouton power, geste de coin d'ecran, etc.).
 * On ne montre aucune interface systeme : on lance directement la bulle Nova
 * en mode ecoute, puis on referme la session immediatement.
 */
class NovaVoiceInteractionSession(context: Context) : VoiceInteractionSession(context) {

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)

        if (Settings.canDrawOverlays(context)) {
            val intent = Intent(context, BubbleService::class.java).apply {
                action = BubbleService.ACTION_LAUNCH_LISTENING
            }
            ContextCompat.startForegroundService(context, intent)
        }

        // On ne garde pas de fenetre systeme ouverte : la bulle geree par
        // BubbleService prend le relais visuellement.
        finish()
    }

    override fun onCreateContentView() = null
}
