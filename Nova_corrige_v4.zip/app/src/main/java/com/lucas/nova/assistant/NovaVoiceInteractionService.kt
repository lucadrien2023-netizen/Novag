package com.lucas.nova.assistant

import android.service.voice.VoiceInteractionService

/**
 * Point d'entree obligatoire pour qu'Android propose Nova dans la liste des
 * applications "Assistant" (Reglages > Applis > Appli assistante par defaut).
 * Le vrai travail se passe dans NovaVoiceInteractionSession, declenchee quand
 * l'utilisateur fait le geste d'assistant (appui long sur le bouton power,
 * ou le geste configure sur le telephone).
 */
class NovaVoiceInteractionService : VoiceInteractionService()
