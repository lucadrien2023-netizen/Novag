package com.lucas.nova.util

import android.content.Context
import android.speech.SpeechRecognizer

/**
 * Cree un SpeechRecognizer avec l'initialisation STANDARD et universelle
 * (SpeechRecognizer.createSpeechRecognizer(context)).
 *
 * Avant : ce fichier cherchait explicitement un ComponentName (moteur Google
 * force en dur, ou decouverte dynamique via PackageManager.queryIntentServices)
 * pour eviter que la reconnaissance ne se resolve vers notre propre stub
 * NovaRecognitionService une fois Nova definie comme assistant par defaut.
 *
 * Ce contournement etait la cause racine du crash ERROR_SERVER_DISCONNECTED
 * (code 11) sur HyperOS (Xiaomi/Redmi) : forcer un ComponentName tiers
 * perturbe la maniere dont ces surcouches lient/autorisent le service de
 * reconnaissance, et la connexion est coupee net. Google recommande de
 * toujours utiliser createSpeechRecognizer(context) et de laisser Android
 * resoudre lui-meme le moteur actif.
 */
object NovaSpeech {

    fun createRecognizer(context: Context): SpeechRecognizer? {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) return null
        return try {
            SpeechRecognizer.createSpeechRecognizer(context)
        } catch (e: Exception) {
            null
        }
    }
}
