package com.lucas.nova.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lucas.nova.data.NovaModel
import com.lucas.nova.data.SettingsStore
import com.lucas.nova.ui.theme.GlassBorder
import com.lucas.nova.ui.theme.MenuItemSurface
import com.lucas.nova.ui.theme.NovaPink
import com.lucas.nova.ui.theme.NovaPurple
import com.lucas.nova.ui.theme.TextPrimary
import com.lucas.nova.ui.theme.TextSecondary
import com.lucas.nova.ui.theme.TextTertiary

/**
 * Logo exact du fichier HTML de reference : icone "calques" (3 formes
 * empilees) trace en degrade violet -> rose, stroke-width 2.5 sur un
 * viewBox 24x24, sans remplissage — copie du chemin SVG fourni par Lucas :
 * "M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"
 */
@Composable
fun NovaLayersLogo(size: Dp = 24.dp) {
    Canvas(modifier = Modifier.size(size)) {
        val scale = this.size.width / 24f
        val strokeW = 2.5f * scale
        val brush = Brush.linearGradient(
            colors = listOf(NovaPurple, NovaPink),
            start = Offset(0f, 0f),
            end = Offset(this.size.width, this.size.height)
        )
        val strokeStyle = Stroke(width = strokeW, cap = StrokeCap.Round, join = StrokeJoin.Round)

        fun x(v: Float) = v * scale
        fun y(v: Float) = v * scale

        // Losange du haut (ferme)
        val diamond = Path().apply {
            moveTo(x(12f), y(2f))
            lineTo(x(2f), y(7f))
            lineTo(x(12f), y(12f))
            lineTo(x(22f), y(7f))
            close()
        }
        drawPath(diamond, brush = brush, style = strokeStyle)

        // Chevron du milieu
        val chevronMid = Path().apply {
            moveTo(x(2f), y(12f))
            lineTo(x(12f), y(17f))
            lineTo(x(22f), y(12f))
        }
        drawPath(chevronMid, brush = brush, style = strokeStyle)

        // Chevron du bas
        val chevronBottom = Path().apply {
            moveTo(x(2f), y(17f))
            lineTo(x(12f), y(22f))
            lineTo(x(22f), y(17f))
        }
        drawPath(chevronBottom, brush = brush, style = strokeStyle)
    }
}

/**
 * Icone "etoile" a 4 branches, style Gemini/sparkle, remplace l'ancien icone
 * "calques" (carres) dans la barre du haut. Meme degrade violet -> rose,
 * mais en remplissage plein (pas de contour) pour un rendu plus doux et rond.
 */
@Composable
fun NovaSparkleLogo(size: Dp = 24.dp) {
    Canvas(modifier = Modifier.size(size)) {
        val scale = this.size.width / 24f
        val brush = Brush.linearGradient(
            colors = listOf(NovaPurple, NovaPink),
            start = Offset(0f, 0f),
            end = Offset(this.size.width, this.size.height)
        )

        fun x(v: Float) = v * scale
        fun y(v: Float) = v * scale

        val sparkle = Path().apply {
            moveTo(x(12f), y(0f))
            cubicTo(x(12f), y(6.075f), x(17.925f), y(12f), x(24f), y(12f))
            cubicTo(x(17.925f), y(12f), x(12f), y(17.925f), x(12f), y(24f))
            cubicTo(x(12f), y(17.925f), x(6.075f), y(12f), x(0f), y(12f))
            cubicTo(x(6.075f), y(12f), x(12f), y(6.075f), x(12f), y(0f))
            close()
        }
        drawPath(sparkle, brush = brush)
    }
}

/**
 * Menu cache : s'ouvre quand on tape discretement sur le titre "Nova" en
 * haut de l'ecran. Liste les modeles disponibles ; ceux qui necessitent une
 * cle API pas encore renseignee apparaissent verrouilles (cadenas), avec un
 * champ pour coller la cle correspondante directement depuis ce menu.
 */
@Composable
fun ModelPickerSheet(
    allModels: List<NovaModel>,
    unlockedModelIds: Set<String>,
    selectedModelId: String,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x66000000))
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onDismiss() },
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .background(Color(0xFFFCFDFF))
                .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { }
                .padding(bottom = 28.dp, top = 8.dp)
        ) {
            Box(
                modifier = Modifier
                    .padding(top = 8.dp, bottom = 12.dp)
                    .align(Alignment.CenterHorizontally)
                    .width(38.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(50))
                    .background(TextTertiary)
            )
            Text(
                "Choisir un modele",
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                modifier = Modifier.padding(horizontal = 22.dp, vertical = 6.dp)
            )
            Text(
                "Les modeles se debloquent des que la cle API Gemini est renseignee dans les reglages.",
                color = TextSecondary,
                fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 22.dp, vertical = 4.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(modifier = Modifier.padding(horizontal = 12.dp)) {
                items(allModels) { model ->
                    val unlocked = unlockedModelIds.contains(model.id)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (model.id == selectedModelId) MenuItemSurface else Color.Transparent)
                            .clickable(enabled = unlocked) { onSelect(model.id) }
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (model.generatesImages) Icons.Filled.Image else Icons.Filled.AutoAwesome,
                            contentDescription = null,
                            tint = if (unlocked) NovaPurple else TextTertiary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                model.label,
                                color = if (unlocked) TextPrimary else TextTertiary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium
                            )
                            if (!unlocked) {
                                Text(
                                    "Cle API requise",
                                    color = TextTertiary,
                                    fontSize = 11.sp
                                )
                            }
                        }
                        when {
                            !unlocked -> Icon(Icons.Filled.Lock, contentDescription = "Verrouille", tint = TextTertiary, modifier = Modifier.size(18.dp))
                            model.id == selectedModelId -> Icon(Icons.Filled.CheckCircle, contentDescription = "Selectionne", tint = NovaPurple, modifier = Modifier.size(20.dp))
                            else -> Icon(Icons.Filled.RadioButtonUnchecked, contentDescription = null, tint = TextTertiary, modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
        }
    }
}
