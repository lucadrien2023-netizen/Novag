package com.lucas.nova.ui

import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lucas.nova.data.ChatMessage
import com.lucas.nova.ui.theme.NovaBlue
import com.lucas.nova.ui.theme.TextPrimary
import com.lucas.nova.ui.theme.UserBubbleEnd
import com.lucas.nova.ui.theme.UserBubbleStart

/**
 * Bulles de message.
 * - Utilisateur : degrade (eclairci) avec fond plein, comme avant.
 * - Nova (IA) : PLUS de bulle de fond du tout, le texte (interprete en
 *   Markdown) est pose directement sur le fond de l'ecran, pour un rendu
 *   plus aere façon "conversation", a la demande de Lucas.
 *
 * Un clic sur n'importe quelle bulle (utilisateur ou IA) ouvre un petit
 * menu contextuel : "Copier le texte" et "Renvoyer la question".
 */
@Composable
fun MessageBubble(
    message: ChatMessage,
    onImageClick: (String) -> Unit = {},
    onResend: (String) -> Unit = {}
) {
    val isUser = message.isUser
    val alignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
    val clipboardManager = LocalClipboardManager.current
    var menuOpen by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 8.dp),
        contentAlignment = alignment
    ) {
        Row(
            horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
        ) {
            val shape = RoundedCornerShape(
                topStart = 24.dp,
                topEnd = 24.dp,
                bottomStart = if (isUser) 24.dp else 6.dp,
                bottomEnd = if (isUser) 6.dp else 24.dp
            )

            val hasImages = message.imagePaths.isNotEmpty()

            val contentModifier = Modifier
                .widthIn(max = 290.dp)
                .let {
                    if (isUser) {
                        it
                            .shadow(
                                elevation = 8.dp,
                                shape = shape,
                                ambientColor = NovaBlue.copy(alpha = 0.30f),
                                spotColor = NovaBlue.copy(alpha = 0.30f)
                            )
                            .clip(shape)
                            .background(Brush.linearGradient(listOf(UserBubbleStart, UserBubbleEnd)))
                    } else {
                        // Aucune bulle de fond pour Nova : le texte respire
                        // directement sur l'arriere-plan de l'ecran. On
                        // garde juste une legere teinte pour les erreurs,
                        // pour que le message d'erreur reste bien visible.
                        if (message.isError) {
                            it.clip(shape).background(Color(0x14EC4899))
                        } else it
                    }
                }
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { menuOpen = true }

            Box(modifier = contentModifier.padding(if (hasImages) 6.dp else 0.dp)) {
                Box(
                    modifier = if (hasImages)
                        Modifier.padding(horizontal = if (isUser) 14.dp else 4.dp, vertical = 8.dp)
                    else
                        Modifier.padding(horizontal = if (isUser) 20.dp else 4.dp, vertical = 14.dp)
                ) {
                    if (hasImages) {
                        Column {
                            AttachedImagesGrid(paths = message.imagePaths, onImageClick = onImageClick)
                            if (message.text.isNotBlank()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                if (isUser) {
                                    Text(
                                        text = message.text,
                                        color = Color.White,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                } else {
                                    MarkdownText(text = message.text, color = TextPrimary, fontSize = 16.sp)
                                }
                            }
                        }
                    } else {
                        if (isUser) {
                            Text(
                                text = message.text,
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium
                            )
                        } else {
                            MarkdownText(text = message.text, color = TextPrimary, fontSize = 16.sp)
                        }
                    }
                }

                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text("Copier le texte") },
                        leadingIcon = { Icon(Icons.Filled.ContentCopy, contentDescription = null) },
                        onClick = {
                            clipboardManager.setText(AnnotatedString(message.text))
                            menuOpen = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Renvoyer la question") },
                        leadingIcon = { Icon(Icons.Filled.Replay, contentDescription = null) },
                        onClick = {
                            onResend(message.text)
                            menuOpen = false
                        }
                    )
                }
            }
        }
    }
}

/**
 * Grille des photos jointes a un message (une ou plusieurs), redimensionnee
 * proprement dans la bulle. Chaque vignette s'agrandit en plein ecran au
 * clic, avec possibilite de la supprimer depuis cet aperçu.
 */
@Composable
private fun AttachedImagesGrid(paths: List<String>, onImageClick: (String) -> Unit) {
    val rows = paths.chunked(2)
    Column {
        rows.forEachIndexed { rowIndex, rowPaths ->
            if (rowIndex > 0) Spacer(modifier = Modifier.height(6.dp))
            Row {
                rowPaths.forEachIndexed { i, path ->
                    if (i > 0) Spacer(modifier = Modifier.width(6.dp))
                    AttachedImageThumbnail(
                        path = path,
                        singleInRow = paths.size == 1,
                        onClick = { onImageClick(path) }
                    )
                }
            }
        }
    }
}

/**
 * Vignette d'une photo jointe a un message, redimensionnee proprement dans
 * la bulle. Coins legerement arrondis, taille bornee pour rester coherente
 * quelle que soit la photo d'origine.
 */
@Composable
private fun AttachedImageThumbnail(path: String, singleInRow: Boolean, onClick: () -> Unit) {
    val bitmapState = produceState<androidx.compose.ui.graphics.ImageBitmap?>(initialValue = null, path) {
        value = runCatching {
            android.graphics.BitmapFactory.decodeFile(path)?.asImageBitmap()
        }.getOrNull()
    }

    val maxSize = if (singleInRow) 220.dp else 130.dp
    Box(
        modifier = Modifier
            .widthIn(max = maxSize)
            .heightIn(max = maxSize)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x14000000))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClick() }
    ) {
        bitmapState.value?.let { bmp ->
            Image(
                bitmap = bmp,
                contentDescription = "Photo jointe",
                modifier = Modifier.widthIn(max = maxSize).heightIn(max = maxSize),
                contentScale = if (singleInRow) ContentScale.FillWidth else ContentScale.Crop
            )
        }
    }
}

@Composable
fun bubbleEnterAnimation() = fadeIn(tween(280)) + slideInVertically(
    animationSpec = tween(280),
    initialOffsetY = { it / 4 }
) + expandVertically(tween(280))
