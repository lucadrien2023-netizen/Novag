package com.lucas.nova.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Fond clair et plat, exactement comme le fichier HTML de référence (--bg-base)
val NovaBgFlat = Color(0xFFF2F2F7)

// Couleurs d'accent, valeurs exactes du design de référence
val NovaPurple = Color(0xFF8B5CF6)
val NovaBlue = Color(0xFF3B82F6)
val NovaPink = Color(0xFFEC4899)

// Degrade de la bulle utilisateur, legerement eclairci par rapport aux
// couleurs d'accent brutes (NovaPurple/NovaBlue) pour un rendu plus doux,
// moins sature, dans la conversation.
val UserBubbleStart = Color(0xFFA78BFA)
val UserBubbleEnd = Color(0xFF60A5FA)

// Panneaux "verre" : reprend --bg-glass (bulle, 0.85) et .glass-ui (chat, 0.6)
val BubbleGlassStrong = Color(0xF5FFFFFF) // bulle assistant vocal, moins transparente qu'avant
val GlassSurface = Color(0x99FFFFFF)      // rgba(255,255,255,0.6) — pilule de saisie, tiroirs
val GlassSurfaceStrong = Color(0x99FFFFFF)
val GlassBorderSolid = Color(0xCCFFFFFF)  // rgba(255,255,255,0.8) — bordure nette du verre

// Liseré "lumière qui accroche le verre" : clair en haut-gauche, plus sombre en bas-droite
val GlassBorder = Brush.linearGradient(
    listOf(
        Color(0xCCFFFFFF),
        Color(0x33FFFFFF),
        Color(0x140A0A2E)
    )
)
val GlassRim = Color(0x0F000000)

val BubbleAi = Color(0xF2FFFFFF)          // blanc quasi plein pour une bulle plus claire/nette

val MenuSurface = Color(0xF7F7FAFA)
val MenuItemSurface = Color(0x99FFFFFF)

val TextPrimary = Color(0xFF1C1C1E)
val TextSecondary = Color(0xFF8E8E93)
val TextTertiary = Color(0xFF8E8E93)

