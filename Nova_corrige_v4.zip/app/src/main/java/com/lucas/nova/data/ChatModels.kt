package com.lucas.nova.data

data class ChatMessage(
    val id: Long = System.nanoTime(),
    val text: String,
    val isUser: Boolean,
    val isError: Boolean = false,
    // Chemins locaux (stockage interne de l'appli) vers les images jointes
    // au message, si l'utilisateur en a attache une ou plusieurs. On ne
    // garde jamais l'URI du picker telle quelle : elle peut perdre son
    // autorisation de lecture apres redemarrage de l'appli, les photos
    // copiees localement, elles, restent toujours accessibles.
    val imagePaths: List<String> = emptyList()
)
