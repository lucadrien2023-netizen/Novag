package com.lucas.nova.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.lucas.nova.ui.theme.NovaBlue
import com.lucas.nova.ui.theme.NovaPink
import com.lucas.nova.ui.theme.NovaPurple
import kotlin.math.cos
import kotlin.math.sin

/**
 * Logo en forme d'etoile a 4 branches, degrade anime, inspire du sparkle
 * de l'app Gemini. thinking = pulsation plus rapide (pendant la reponse).
 */
@Composable
fun NovaOrb(size: Dp = 32.dp, thinking: Boolean = false) {
    val transition = rememberInfiniteTransition(label = "orb")

    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (thinking) 2200 else 6000, easing = LinearEasing)
        ),
        label = "rotation"
    )

    val pulse by transition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (thinking) 500 else 1400),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Canvas(modifier = Modifier.size(size)) {
        rotate(rotation) {
            val w = this.size.width
            val h = this.size.height
            val cx = w / 2f
            val cy = h / 2f
            val outer = (w / 2f) * pulse
            val inner = outer * 0.38f

            val path = Path()
            for (i in 0 until 8) {
                val angle = Math.toRadians((i * 45).toDouble())
                val radius = if (i % 2 == 0) outer else inner
                val x = cx + (radius * cos(angle)).toFloat()
                val y = cy + (radius * sin(angle)).toFloat()
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()

            drawPath(
                path = path,
                brush = Brush.linearGradient(
                    colors = listOf(NovaPurple, NovaBlue, NovaPink),
                    start = Offset(0f, 0f),
                    end = Offset(w, h)
                )
            )
        }
    }
}
