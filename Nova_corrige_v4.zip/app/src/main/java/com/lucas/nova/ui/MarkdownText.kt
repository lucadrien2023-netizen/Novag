package com.lucas.nova.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Rendu Markdown minimal, sans dependance externe (pas de librairie tierce
 * dans build.gradle : evite d'ajouter un depot supplementaire juste pour
 * ca). Couvre ce que Gemini utilise le plus souvent dans ses reponses :
 * titres (#, ##, ###), gras (**...**), italique (*...* / _..._), code
 * inline (`...`), listes a puces (- / *) et listes numerotees (1.).
 */
@Composable
fun MarkdownText(
    text: String,
    color: Color,
    fontSize: androidx.compose.ui.unit.TextUnit = 16.sp,
    fontWeight: FontWeight = FontWeight.Normal
) {
    val lines = text.split("\n")
    Column {
        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            when {
                line.isBlank() -> Spacer(modifier = Modifier.height(6.dp))
                line.startsWith("### ") -> Text(
                    text = inlineMarkdown(line.removePrefix("### "), color),
                    fontSize = fontSize.value.sp * 1.05f,
                    fontWeight = FontWeight.Bold
                )
                line.startsWith("## ") -> Text(
                    text = inlineMarkdown(line.removePrefix("## "), color),
                    fontSize = fontSize.value.sp * 1.15f,
                    fontWeight = FontWeight.Bold
                )
                line.startsWith("# ") -> Text(
                    text = inlineMarkdown(line.removePrefix("# "), color),
                    fontSize = fontSize.value.sp * 1.3f,
                    fontWeight = FontWeight.Bold
                )
                line.trimStart().startsWith("- ") || line.trimStart().startsWith("* ") -> {
                    val content = line.trimStart().removePrefix("- ").removePrefix("* ")
                    Row(horizontalArrangement = Arrangement.Start) {
                        Text("•  ", color = color, fontSize = fontSize, fontWeight = fontWeight)
                        Text(inlineMarkdown(content, color), fontSize = fontSize, fontWeight = fontWeight)
                    }
                }
                Regex("^\\d+\\.\\s").containsMatchIn(line.trimStart()) -> {
                    val trimmed = line.trimStart()
                    val marker = Regex("^\\d+\\.").find(trimmed)?.value ?: "•"
                    val content = trimmed.removePrefix(marker).trim()
                    Row(horizontalArrangement = Arrangement.Start) {
                        Text("$marker  ", color = color, fontSize = fontSize, fontWeight = fontWeight)
                        Text(inlineMarkdown(content, color), fontSize = fontSize, fontWeight = fontWeight)
                    }
                }
                else -> Text(
                    text = inlineMarkdown(line, color),
                    fontSize = fontSize,
                    fontWeight = fontWeight
                )
            }
            i++
        }
    }
}

/** Traite le formatage "en ligne" : gras, italique, code inline. Les liens
 * [texte](url) sont affiches en gras colore (pas de vrai lien cliquable
 * pour rester simple, mais l'URL n'est plus perdue visuellement). */
private fun inlineMarkdown(raw: String, baseColor: Color): androidx.compose.ui.text.AnnotatedString {
    return buildAnnotatedString {
        var idx = 0
        val len = raw.length
        while (idx < len) {
            when {
                raw.startsWith("**", idx) -> {
                    val end = raw.indexOf("**", idx + 2)
                    if (end == -1) { append(raw.substring(idx)); idx = len }
                    else {
                        withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(raw.substring(idx + 2, end)) }
                        idx = end + 2
                    }
                }
                raw.startsWith("`", idx) -> {
                    val end = raw.indexOf("`", idx + 1)
                    if (end == -1) { append(raw.substring(idx)); idx = len }
                    else {
                        withStyle(
                            SpanStyle(
                                fontWeight = FontWeight.Medium,
                                background = baseColor.copy(alpha = 0.08f)
                            )
                        ) { append(raw.substring(idx + 1, end)) }
                        idx = end + 1
                    }
                }
                (raw.startsWith("*", idx) && !raw.startsWith("**", idx)) || raw.startsWith("_", idx) -> {
                    val marker = raw[idx]
                    val end = raw.indexOf(marker, idx + 1)
                    if (end == -1) { append(raw.substring(idx)); idx = len }
                    else {
                        withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { append(raw.substring(idx + 1, end)) }
                        idx = end + 1
                    }
                }
                raw.startsWith("[", idx) -> {
                    val closeBracket = raw.indexOf("]", idx)
                    val openParen = if (closeBracket != -1) closeBracket + 1 else -1
                    val closeParen = if (openParen != -1 && openParen < len && raw[openParen] == '(') raw.indexOf(")", openParen) else -1
                    if (closeBracket != -1 && closeParen != -1) {
                        val label = raw.substring(idx + 1, closeBracket)
                        withStyle(SpanStyle(fontWeight = FontWeight.SemiBold, textDecoration = androidx.compose.ui.text.style.TextDecoration.Underline)) {
                            append(label)
                        }
                        idx = closeParen + 1
                    } else {
                        append(raw[idx]); idx++
                    }
                }
                else -> { append(raw[idx]); idx++ }
            }
        }
    }
}
