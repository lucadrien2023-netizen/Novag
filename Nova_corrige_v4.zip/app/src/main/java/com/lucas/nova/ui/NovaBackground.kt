package com.lucas.nova.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.dp
import com.lucas.nova.ui.theme.NovaBgFlat
import com.lucas.nova.ui.theme.NovaBlue
import com.lucas.nova.ui.theme.NovaPurple

/**
 * Fond exactement comme le fichier de reference : une base plate (--bg-base)
 * et deux taches floues qui derivent lentement (.blob1 violet en haut a
 * gauche, .blob2 bleu en bas a droite), rien de plus.
 */
@Composable
fun NovaBackground(content: @Composable () -> Unit) {
    val transition = rememberInfiniteTransition(label = "bg")

    val drift1 by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(15000), RepeatMode.Reverse),
        label = "drift1"
    )
    val drift2 by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(18000), RepeatMode.Reverse),
        label = "drift2"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NovaBgFlat)
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .blur(80.dp)
        ) {
            val w = size.width
            val h = size.height

            // blob1 : violet, en haut a gauche, opacite 0.3 (proche de .blob1 du HTML)
            drawCircle(
                color = NovaPurple.copy(alpha = 0.30f),
                radius = w * 0.42f,
                center = Offset(w * (-0.10f + drift1 * 0.14f), h * (-0.05f + drift1 * 0.10f))
            )

            // blob2 : bleu, en bas a droite, opacite 0.2 (proche de .blob2 du HTML)
            drawCircle(
                color = NovaBlue.copy(alpha = 0.20f),
                radius = w * 0.48f,
                center = Offset(w * (1.05f - drift2 * 0.20f), h * (1.05f - drift2 * 0.12f))
            )
        }

        content()
    }
}
