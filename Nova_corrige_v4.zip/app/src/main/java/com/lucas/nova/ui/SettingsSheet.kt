package com.lucas.nova.ui

import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lucas.nova.data.SettingsStore
import com.lucas.nova.ui.theme.GlassBorder
import com.lucas.nova.ui.theme.MenuItemSurface
import com.lucas.nova.ui.theme.NovaBlue
import com.lucas.nova.ui.theme.NovaPink
import com.lucas.nova.ui.theme.NovaPurple
import com.lucas.nova.ui.theme.TextPrimary
import com.lucas.nova.ui.theme.TextSecondary
import com.lucas.nova.ui.theme.TextTertiary

private enum class SettingsField { NONE, API_KEY, NAME, PROMPT }

@Composable
fun SettingsSheet(
    initialKey: String,
    initialName: String,
    initialPrompt: String,
    bubbleEnabled: Boolean,
    isDefaultAssistant: Boolean,
    onSave: (apiKey: String, name: String, prompt: String) -> Unit,
    onDismiss: () -> Unit,
    onDeleteAll: () -> Unit,
    onToggleBubble: (Boolean) -> Unit,
    onRequestAssistantRole: () -> Unit
) {
    val context = LocalContext.current
    val settingsStore = remember { SettingsStore(context) }
    var apiKey by remember { mutableStateOf(initialKey) }
    var name by remember { mutableStateOf(initialName) }
    var prompt by remember { mutableStateOf(initialPrompt) }
    var editing by remember { mutableStateOf(SettingsField.NONE) }
    var confirmDelete by remember { mutableStateOf(false) }
    var voiceSelectorOpen by remember { mutableStateOf(false) }
    var selectedVoiceLabel by remember { mutableStateOf(settingsStore.getVoiceName()?.let { voiceDisplayName(it) } ?: "Voix par défaut") }

    fun commit() = onSave(apiKey, name, prompt)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFBFCFF))
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 40.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Réglages", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(MenuItemSurface)
                        .clickable { commit(); onDismiss() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Close, contentDescription = "Fermer", tint = TextSecondary, modifier = Modifier.size(16.dp))
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                NovaOrb(size = 56.dp)
                Spacer(modifier = Modifier.height(10.dp))
                Text("Bonjour, je suis $name", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            }

            Spacer(modifier = Modifier.height(22.dp))

            LazyColumn(modifier = Modifier.weight(1f), contentPadding = PaddingValues(bottom = 20.dp)) {
                item { SectionLabel("Connexion") }
                item {
                    SettingsRow(
                        icon = Icons.Filled.Key,
                        label = "Clé API Gemini",
                        value = if (apiKey.isBlank()) "Non configurée" else "•••• ${apiKey.takeLast(4)}",
                        onClick = { editing = SettingsField.API_KEY }
                    )
                }

                item { SectionLabel("Personnalisation") }
                item {
                    SettingsRow(
                        icon = Icons.Filled.Person,
                        label = "Nom de l'assistant",
                        value = name,
                        onClick = { editing = SettingsField.NAME }
                    )
                }
                item {
                    SettingsRow(
                        icon = Icons.Filled.Psychology,
                        label = "Personnalité / instructions",
                        value = "Modifier le comportement de $name",
                        onClick = { editing = SettingsField.PROMPT }
                    )
                }

                item { SectionLabel("Assistant vocal") }
                item {
                    SettingsRow(
                        icon = if (isDefaultAssistant) Icons.Filled.RadioButtonChecked else Icons.Filled.RadioButtonUnchecked,
                        label = if (isDefaultAssistant) "Nova est ton assistant par défaut" else "Définir Nova comme assistant du téléphone",
                        value = if (isDefaultAssistant) "Le geste d'assistant (appui long sur le bouton power) ouvre Nova" else "Nécessaire pour que le geste d'assistant lance la bulle",
                        onClick = { onRequestAssistantRole() }
                    )
                }
                item {
                    SettingsRow(
                        icon = if (bubbleEnabled) Icons.Filled.RadioButtonChecked else Icons.Filled.RadioButtonUnchecked,
                        label = if (bubbleEnabled) "Bulle flottante activée" else "Activer la bulle flottante",
                        value = if (bubbleEnabled) "Nova est disponible par-dessus tes autres apps" else "Micro réel + réponses Gemini, comme un vrai assistant",
                        onClick = { onToggleBubble(!bubbleEnabled) }
                    )
                }
                item {
                    SettingsRow(
                        icon = Icons.Filled.Mic,
                        label = "Voix de l'assistant",
                        value = selectedVoiceLabel,
                        onClick = { voiceSelectorOpen = true }
                    )
                }

                item { SectionLabel("Données") }
                item {
                    SettingsRow(
                        icon = Icons.Filled.DeleteForever,
                        label = "Effacer toutes les conversations",
                        value = "",
                        onClick = { confirmDelete = true },
                        destructive = true
                    )
                }
                item {
                    SettingsRow(
                        icon = Icons.Filled.Info,
                        label = "À propos de Nova",
                        value = "Version 1.0 — projet perso de Lucas",
                        onClick = {}
                    )
                }

                item { Spacer(modifier = Modifier.height(40.dp)) }
            }
        }

        if (editing != SettingsField.NONE) {
            EditFieldDialog(
                field = editing,
                apiKey = apiKey,
                name = name,
                prompt = prompt,
                onApiKeyChange = { apiKey = it },
                onNameChange = { name = it },
                onPromptChange = { prompt = it },
                onClose = {
                    editing = SettingsField.NONE
                    commit()
                }
            )
        }

        if (voiceSelectorOpen) {
            VoiceSelectorDialog(
                currentVoiceName = settingsStore.getVoiceName(),
                onSelect = { voice ->
                    settingsStore.setVoiceName(voice?.name)
                    selectedVoiceLabel = voice?.let { voiceDisplayName(it.name) } ?: "Voix par défaut"
                    voiceSelectorOpen = false
                },
                onClose = { voiceSelectorOpen = false }
            )
        }

        if (confirmDelete) {
            ConfirmDialog(
                title = "Effacer toutes les conversations ?",
                message = "Cette action est définitive et supprimera tout ton historique avec $name.",
                onCancel = { confirmDelete = false },
                onConfirm = {
                    confirmDelete = false
                    onDeleteAll()
                }
            )
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text.uppercase(),
        color = TextTertiary,
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
    )
}

@Composable
private fun SettingsRow(
    icon: ImageVector,
    label: String,
    value: String,
    onClick: () -> Unit,
    disabled: Boolean = false,
    destructive: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = !disabled) { onClick() }
            .padding(horizontal = 20.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            icon,
            contentDescription = null,
            tint = when {
                destructive -> NovaPink
                disabled -> TextTertiary
                else -> TextSecondary
            },
            modifier = Modifier.size(21.dp)
        )
        Spacer(modifier = Modifier.width(18.dp))
        Column {
            Text(
                label,
                color = if (destructive) NovaPink else if (disabled) TextTertiary else TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium
            )
            if (value.isNotBlank()) {
                Text(value, color = TextTertiary, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun EditFieldDialog(
    field: SettingsField,
    apiKey: String,
    name: String,
    prompt: String,
    onApiKeyChange: (String) -> Unit,
    onNameChange: (String) -> Unit,
    onPromptChange: (String) -> Unit,
    onClose: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x66000000))
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onClose() },
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp)
                .shadow(16.dp, RoundedCornerShape(24.dp))
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFFFFFFFF))
                .border(1.dp, GlassBorder, RoundedCornerShape(24.dp))
                .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { }
                .padding(24.dp)
        ) {
            when (field) {
                SettingsField.API_KEY -> {
                    Text("Clé API Gemini", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Depuis aistudio.google.com/apikey", color = TextSecondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedTextField(
                        value = apiKey,
                        onValueChange = onApiKeyChange,
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("AIza...") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        colors = settingsFieldColors()
                    )
                }
                SettingsField.NAME -> {
                    Text("Nom de l'assistant", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedTextField(
                        value = name,
                        onValueChange = onNameChange,
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Nova") },
                        singleLine = true,
                        colors = settingsFieldColors()
                    )
                }
                SettingsField.PROMPT -> {
                    Text("Personnalité de l'assistant", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Ces instructions sont envoyées à Gemini avant chaque conversation.", color = TextSecondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedTextField(
                        value = prompt,
                        onValueChange = onPromptChange,
                        modifier = Modifier.fillMaxWidth().height(140.dp),
                        colors = settingsFieldColors()
                    )
                }
                SettingsField.NONE -> {}
            }

            Spacer(modifier = Modifier.height(18.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(NovaPurple, NovaBlue)))
                    .clickable { onClose() }
                    .padding(vertical = 13.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Enregistrer", color = Color.White, fontWeight = FontWeight.Medium)
            }
        }
    }
}

/** Nettoie le nom technique d'une voix Android (ex: "fr-fr-x-fsc-local")
 * en quelque chose de lisible, faute de nom marketing fourni par le systeme. */
private fun voiceDisplayName(raw: String): String {
    val cleaned = raw
        .replace(Regex("(?i)fr-fr-x-"), "")
        .replace(Regex("(?i)-local|-network"), "")
        .replace("_", " ")
        .replace("-", " ")
        .trim()
    if (cleaned.isBlank()) return raw
    return cleaned.split(" ").filter { it.isNotBlank() }.joinToString(" ") { it.replaceFirstChar(Char::uppercase) }
}

private val voiceAvatarColors = listOf(
    Brush.linearGradient(listOf(NovaPurple, NovaBlue)),
    Brush.linearGradient(listOf(NovaBlue, NovaPink)),
    Brush.linearGradient(listOf(NovaPurple, NovaPink))
)

/**
 * Popup de selection de la voix TTS : liste les voix francaises disponibles
 * sur le telephone, chacune avec un avatar rond minimaliste (silhouette
 * tete + epaules) et un bouton pour l'ecouter avant de la choisir.
 */
@Composable
private fun VoiceSelectorDialog(
    currentVoiceName: String?,
    onSelect: (Voice?) -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    var voices by remember { mutableStateOf<List<Voice>>(emptyList()) }
    var ready by remember { mutableStateOf(false) }
    var previewing by remember { mutableStateOf<String?>(null) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }

    DisposableEffect(Unit) {
        val engine = TextToSpeech(context) { }
        tts = engine
        onDispose {
            engine.stop()
            engine.shutdown()
        }
    }

    LaunchedEffect(tts) {
        val engine = tts ?: return@LaunchedEffect
        // On laisse un court instant au moteur pour finir son init avant de
        // lire la liste des voix (sinon elle peut arriver vide).
        kotlinx.coroutines.delay(350)
        val french = engine.voices
            ?.filter { it.locale?.language == "fr" && !it.isNetworkConnectionRequired }
            ?.sortedBy { it.name }
            .orEmpty()
        voices = french
        ready = true
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x66000000))
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onClose() },
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(14.dp, RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .background(Color(0xFFFCFDFF))
                .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { }
                .padding(bottom = 24.dp, top = 8.dp)
        ) {
            Box(
                modifier = Modifier
                    .padding(top = 8.dp, bottom = 12.dp)
                    .align(Alignment.CenterHorizontally)
                    .width(38.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(50))
                    .background(TextTertiary)
            )
            Text(
                "Voix de l'assistant",
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                modifier = Modifier.padding(horizontal = 22.dp, vertical = 6.dp)
            )

            if (!ready) {
                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = NovaPurple, modifier = Modifier.size(26.dp), strokeWidth = 3.dp)
                }
            } else {
                LazyColumn(modifier = Modifier.height(360.dp)) {
                    item {
                        VoiceRow(
                            label = "Voix par défaut",
                            colorIndex = -1,
                            selected = currentVoiceName == null,
                            isPreviewing = false,
                            onPreview = {},
                            onClick = { onSelect(null) }
                        )
                    }
                    itemsIndexed(voices) { index, voice ->
                        VoiceRow(
                            label = voiceDisplayName(voice.name),
                            colorIndex = index,
                            selected = voice.name == currentVoiceName,
                            isPreviewing = previewing == voice.name,
                            onPreview = {
                                previewing = voice.name
                                tts?.voice = voice
                                tts?.speak("Bonjour, je suis Nova, ton assistant intelligent.", TextToSpeech.QUEUE_FLUSH, null, "preview")
                            },
                            onClick = { onSelect(voice) }
                        )
                    }
                    item { Spacer(modifier = Modifier.height(8.dp)) }
                }
            }
        }
    }
}

@Composable
private fun VoiceRow(
    label: String,
    colorIndex: Int,
    selected: Boolean,
    isPreviewing: Boolean,
    onPreview: () -> Unit,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .background(if (selected) Color(0x140A0A2E) else Color.Transparent)
            .padding(horizontal = 22.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(
                    if (colorIndex < 0) Brush.linearGradient(listOf(TextTertiary, TextTertiary))
                    else voiceAvatarColors[colorIndex % voiceAvatarColors.size]
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Person, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
        }
        Spacer(modifier = Modifier.width(14.dp))
        Text(
            label,
            color = TextPrimary,
            fontSize = 15.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            modifier = Modifier.weight(1f)
        )
        if (colorIndex >= 0) {
            Icon(
                Icons.Filled.PlayCircleOutline,
                contentDescription = "Écouter",
                tint = if (isPreviewing) NovaPurple else TextSecondary,
                modifier = Modifier.size(24.dp).clickable { onPreview() }
            )
        }
    }
}

@Composable
private fun settingsFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = TextPrimary,
    unfocusedTextColor = TextPrimary,
    focusedBorderColor = NovaBlue,
    unfocusedBorderColor = Color(0x1F0A0A2E),
    cursorColor = NovaBlue
)

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmLabel: String = "Supprimer",
    onCancel: () -> Unit,
    onConfirm: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x66000000))
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onCancel() },
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp)
                .shadow(16.dp, RoundedCornerShape(24.dp))
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFFFFFFFF))
                .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { }
                .padding(22.dp)
        ) {
            Text(title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Text(message, color = TextSecondary, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(20.dp))
            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                Text(
                    "Annuler",
                    color = TextSecondary,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onCancel() }
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    confirmLabel,
                    color = NovaPink,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onConfirm() }
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                )
            }
        }
    }
}
