# Nova — Chat + Assistant vocal en bulle

## Pour ouvrir le projet

1. Dézippe le dossier `Nova`.
2. Android Studio → **Open** → sélectionne le dossier `Nova`.
3. Laisse Android Studio faire le **Gradle Sync** (connecté au wifi la première fois).
4. Build > Run sur ton Redmi Note 14 5G.

## Ce que fait cette version

### Chat
- Interface complète en verre liquide clair, avec dégradé de fond animé
- Menu ☰ → tiroir latéral avec historique des conversations (épingler / renommer / supprimer), et bouton Réglages en bas
- Réglages complets : clé API Gemini, nom de l'assistant, personnalité/prompt système, suppression des conversations

### Assistant vocal en bulle
- Dans Réglages → **"Définir Nova comme assistant du téléphone"** : ouvre l'écran système Android qui permet de choisir Nova comme application assistante par défaut (nécessite Android 10+ ; sur les téléphones plus anciens ou si le fabricant cache ce choix, ça ouvre l'écran classique "Assistant et saisie vocale").
- Une fois Nova définie comme assistant, **le geste d'assistant de ton téléphone** (appui long sur le bouton power, ou le geste que tu as configuré) **lance directement la bulle Nova en mode écoute** — exactement comme demandé.
- Dans Réglages → "Activer la bulle flottante" : l'app demande d'affilée la permission **Afficher par-dessus les autres applications**, la permission **Micro**, puis (Android 13+) l'autorisation de notifications. C'est ce qui permet à la bulle de s'afficher et d'écouter, que ce soit lancée depuis l'app ou depuis le geste d'assistant.
- Une fois activée, une petite bulle Nova reste visible par-dessus tes autres applications (comme les bulles Messenger), déplaçable du doigt.
- Tape la bulle (ou fais le geste d'assistant) → elle s'agrandit en ovale et écoute réellement via le micro du téléphone (reconnaissance vocale native Android, gratuite).
- Elle réfléchit (appel réel à Gemini avec ta clé API), puis affiche la réponse dans une bulle élargie, avec une zone de saisie texte et un bouton micro pour relancer une question.
- Service au premier plan avec une notification permanente discrète (obligatoire sur Android pour ce type de fonctionnalité) — tape "Désactiver la bulle flottante" dans les Réglages pour l'arrêter.

### Limites connues à garder en tête
- **Sur MIUI (Xiaomi/Redmi)** : Xiaomi restreint parfois le choix de l'appli assistante aux apps Google/Xiaomi. Si l'écran système ne propose pas Nova, essaie Réglages téléphone > Applis > Applis par défaut > Application assistante (ou "Assistant numérique") directement dans les réglages MIUI, en dehors de l'app. Il peut aussi falloir activer manuellement "Autoriser l'affichage en superposition" pour Nova dans Réglages > Applis > Autorisations spéciales si la permission système ne suffit pas.
- Le geste d'assistant lui-même (quel geste déclenche l'assistant : appui long power, pincement, geste de coin...) est configuré au niveau du système/launcher, pas par Nova — Nova ne fait que répondre à Android quand ce geste est fait, si Nova est bien définie comme assistant.
- La reconnaissance vocale utilise le moteur intégré d'Android (Google), pas d'IA à toi — gratuit.
- Pas encore branché : SMS, appels, agenda, recherche web, silencieux/volume (toujours listés comme "bientôt" dans le menu et les réglages).

## Pour obtenir une clé API Gemini (gratuite)

1. Va sur https://aistudio.google.com/apikey
2. Crée une clé API gratuite.
3. Colle-la dans Réglages → Clé API Gemini (utilisée à la fois par le chat et par la bulle).
